#include "glaurung.h"

static void init_engine_options() {
  EngineOptions.analyse = get_option_value_bool("UCI_AnalyseMode");
  if(EngineOptions.analyse) 
    EngineOptions.ks_weight[XSide] = EngineOptions.ks_weight[Side] =
      (((get_option_value_int("Aggressiveness") * 128) / 100) +
       ((get_option_value_int("Cowardice") * 128) / 100)) / 2;
  else {
    EngineOptions.ks_weight[XSide] = 
      (get_option_value_int("Aggressiveness") * 128) / 100;
    EngineOptions.ks_weight[Side] =
      (get_option_value_int("Cowardice") * 128) / 100;
  }
  EngineOptions.pp_weight = 
    (get_option_value_int("Passed pawns") * 128) / 100;
  EngineOptions.ps_weight = 
    (get_option_value_int("Pawn structure") * 128) / 100;
  EngineOptions.mob_weight = 
    (get_option_value_int("Mobility (middle game)") * 128) / 100;
  EngineOptions.e_mob_weight = 
    (get_option_value_int("Mobility (endgame)") * 128) / 100;
  EngineOptions.space_weight = 
    (get_option_value_int("Space") * 128) / 100;
  EngineOptions.development_weight = 
    (get_option_value_int("Development") * 128) / 100;
  EngineOptions.use_eval_cache = 
    get_option_value_bool("Static evaluation cache");
  EngineOptions.eval_cache_size = 
    get_option_value_int("Static evaluation cache size");
  EngineOptions.static_pruning =
    get_option_value_bool("Static null move pruning");
  EngineOptions.pruning_depth =
    get_option_value_int("Static pruning depth");
  EngineOptions.qs_checks = 
    get_option_value_int("Checks in quiescence search");
  EngineOptions.learning = 
    get_option_value_bool("Position learning");
  if(button_was_pushed("Clear position learning")) clear_learning();
  EngineOptions.ponder = get_option_value_bool("Ponder");
  EngineOptions.frc = get_option_value_bool("UCI_Chess960");
  EngineOptions.currline = get_option_value_bool("UCI_ShowCurrLine");
  EngineOptions.own_book = get_option_value_bool("OwnBook");
  EngineOptions.multipv = get_option_value_int("MultiPV");
  init_tt(get_option_value_int("Hash"));
  if(button_was_pushed("Clear Hash")) clear_tt();
  init_eval_cache();
}

void think(int inf, int wtime, int btime, int winc, int binc, int movestogo, 
           int ponder, int depth_limit, int node_limit, int exact_time,
           move_t moves[]) {
  position_t p;
  int time, inc;

  init_root_search_info();
  init_engine_options();

  if(!inf && GPly < 60 && EngineOptions.own_book) {
    move_t book_move = pick_book_move(Book, Pos.key);
    if(book_move != 0) {
      RootSearchInfo.bestmove = book_move; RootSearchInfo.pondermove = 0;
      return;
    }
  }

  if(Side == WHITE) { time = wtime; inc = winc; }
  else { time = btime; inc = binc; }

  /* If a node, depth or time limit is given, but no time, use infinite time: */
  if(time == 0 && inc == 0 && (depth_limit || node_limit || exact_time)) 
    inf = 1;

  if(!movestogo) { /* Sudden death time control */
    if(inc) {
      RootSearchInfo.max_time = time / 30 + inc;
      RootSearchInfo.absolute_max_time = max(time / 4, inc - 100);
    } else {
      RootSearchInfo.max_time = time / 40;
      RootSearchInfo.absolute_max_time = time / 8;
    }
  } else { /* x moves/y minutes */
    if(movestogo == 1) {
      RootSearchInfo.max_time = time / 2;
      RootSearchInfo.absolute_max_time = min(time / 2, time - 500);
    } else {
      RootSearchInfo.max_time = time / min(movestogo, 20);
      RootSearchInfo.absolute_max_time = min((4 * time) / movestogo, time / 3);
    }
  }
  if(EngineOptions.ponder) {
    RootSearchInfo.max_time += RootSearchInfo.max_time / 4;
    if(RootSearchInfo.max_time > RootSearchInfo.absolute_max_time)
      RootSearchInfo.max_time = RootSearchInfo.absolute_max_time;
  }

  RootSearchInfo.infinite = inf;
  RootSearchInfo.depth_limit = depth_limit;
  RootSearchInfo.node_limit = node_limit;
  RootSearchInfo.exact_time = exact_time;
  RootSearchInfo.thinking_status = ponder? PONDERING : THINKING;
  RootSearchInfo.nodes_between_polls = RootSearchInfo.node_limit ?
    min(RootSearchInfo.node_limit, 20000) : 20000;

  if(!inf && !ponder && !node_limit && !depth_limit && !exact_time &&
     EngineOptions.learning) {
    move_t lmove, lpmove;
    if(get_learning_data_at_root(Pos.key, RootSearchInfo.absolute_max_time,
                                 &lmove, &lpmove)) {
      RootSearchInfo.bestmove = lmove; RootSearchInfo.pondermove = lpmove;
      return;
    }
  }

  init_search();
  copy_position(&Pos, &p);
  root_search(moves);
  copy_position(&p, &Pos);
}

