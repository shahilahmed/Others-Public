#ifndef _MSC_VER
#include <unistd.h>
#include <sys/time.h>
#else
#include <windows.h>
#define inline __inline
int             strncasecmp(const char *, const char *, size_t);
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include <ctype.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>


/***************************************************************************
 *                         Constants and macros                            *
 ***************************************************************************/

#define ENGINE_NAME "Glaurung"
#define ENGINE_VERSION "1.0.2"

#define STARTPOS "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w AHah - 0 0"

#define MAX_DEPTH 64
#define MAX_GAME_LENGTH 1024
#define MOVE_STACK_SIZE 2048

#define PLY 60

enum {WHITE, BLACK};

enum {PAWN=1, KNIGHT=2, BISHOP=3, ROOK=4, QUEEN=5, KING=6};
enum {WP=1, WN=2, WB=3, WR=4, WQ=5, WK=6, 
      BP=9, BN=10, BB=11, BR=12, BQ=13, BK=14,
      EMPTY=16, OUTSIDE=32};

#define P_VALUE 0x100
#define N_VALUE 0x340
#define B_VALUE 0x340
#define R_VALUE 0x50C
#define Q_VALUE 0x9F0
#define K_VALUE 0x1000

#define MATE_VALUE 30000
#define DRAW_VALUE 0
#define KNOWN_WIN (2*Q_VALUE)

#define MIDGAME_MATERIAL (2*Q_VALUE + 2*R_VALUE + 4*B_VALUE)
#define ENDGAME_MATERIAL (4*R_VALUE + 2*B_VALUE)

#define FriendlyPawn (PAWN|(Side<<3))
#define FriendlyKnight (KNIGHT|(Side<<3))
#define FriendlyBishop (BISHOP|(Side<<3))
#define FriendlyRook (ROOK|(Side<<3))
#define FriendlyQueen (QUEEN|(Side<<3))
#define FriendlyKing (KING|(Side<<3))
#define EnemyPawn (PAWN|(XSide<<3))
#define EnemyKnight (KNIGHT|(XSide<<3))
#define EnemyBishop (BISHOP|(XSide<<3))
#define EnemyRook (ROOK|(XSide<<3))
#define EnemyQueen (QUEEN|(XSide<<3))
#define EnemyKing (KING|(XSide<<3))

enum {FILE_A, FILE_B, FILE_C, FILE_D, FILE_E, FILE_F, FILE_G, FILE_H};
enum {RANK_1, RANK_2, RANK_3, RANK_4, RANK_5, RANK_6, RANK_7, RANK_8};

#define COLOUR(x) ((x)>>3)
#define PIECE_TYPE(x) ((x)&7)

#define Board Pos.board
#define Side Pos.side
#define XSide Pos.xside

#define KSQ(x) (Pos.piece_list[(((x)<<3)|KING)+128].n)
#define PL(x) (Pos.piece_list[(x)])
#define PL_START(x) (Pos.piece_list[(x)+128].n)
#define PL_NEXT(x) (Pos.piece_list[(x)].n)
#define PL_PREV(x) (Pos.piece_list[(x)].p)

#define PL_REMOVE(x) do {\
  PL_NEXT(PL_PREV(x)) = PL_NEXT(x); PL_PREV(PL_NEXT(x)) = PL_PREV(x);\
} while(0)

#define PL_INSERT(x,y) do {\
  PL_NEXT(y) = PL_START(x); PL_PREV(PL_NEXT(y)) = y;\
  PL_PREV(y) = x+128; PL_START(x) = y;\
} while(0)

#define PL_MOVE(x,y) do {\
  PL(y)=PL(x); PL_PREV(PL_NEXT(y)) = PL_NEXT(PL_PREV(y)) = y;\
} while(0)

#define PL_END (BK+128+1)

#define NULLMOVE 0
#define FROM(x) (((x)>>7)&127)
#define TO(x) ((x)&127)
#define PROMOTION(x) (((x)>>14)&7)
#define PIECE(x) (((x)>>17)&7)
#define CAPTURE(x) (((x)>>20)&7)
#define EP_FLAG (1<<23)
#define EP(x) ((x)&EP_FLAG)
/* FRC stuff: */
#define CASTLE_FLAG (1<<24)

#define SLIDER(x) (SlidingArray[x])

#define WP_MASK 1
#define BP_MASK 2
#define N_MASK 4
#define K_MASK 8
#define B_MASK 16
#define R_MASK 32
#define Q_MASK 64

#define CHECK_EXT_MASK 1
#define SINGLE_REPLY_EXT_MASK 2
#define RECAPTURE_EXT_MASK 4
#define MATE_THREAT_EXT_MASK 8

#define EXPAND(x) ((x)+((x)&~7))
#define COMPRESS(x) (((x)+((x)&7))>>1)

#define ZOBRIST(x,y) Zobrist[(x)-1][COMPRESS(y)]
#define ZOB_EP(y) ZobEP[COMPRESS(y)]
#define ZOB_CASTLE(y) ZobCastle[y]

#define PSQ(x,y) PSqTables[x][y]
#define KING_ENDGAME_PSQ(x) KingEndgamePsq[x]

#define FIND_CHECKERS() do { \
  SearchStack[Ply].check=(Ply>0)? \
    fast_find_checkers(SearchStack[Ply].checkers) : \
    find_checkers(SearchStack[Ply].checkers); \
} while(0)

#define HINDEX(x) ((COMPRESS(FROM(x))<<6)|(COMPRESS(TO(x))))
#define HISTORY(x,y) (History[x][HINDEX(y)])

#define max(x,y) (((x)>(y))?(x):(y))
#define min(x,y) (((x)<(y))?(x):(y))

#define file(x) ((x)&15)
#define rank(x) ((x)>>4)

#define DISTANCE(x, y) (Distance[(x)-(y)])

enum {LOWER_BOUND=1, UPPER_BOUND=2, EXACT=3};

enum {IDLE, THINKING, PONDERING, PONDERHIT, ABORTED};

enum {
  A1=0x00, B1=0x01, C1=0x02, D1=0x03, E1=0x04, F1=0x05, G1=0x06, H1=0x07,
  A2=0x10, B2=0x11, C2=0x12, D2=0x13, E2=0x14, F2=0x15, G2=0x16, H2=0x17,
  A3=0x20, B3=0x21, C3=0x22, D3=0x23, E3=0x24, F3=0x25, G3=0x26, H3=0x27,
  A4=0x30, B4=0x31, C4=0x32, D4=0x33, E4=0x34, F4=0x35, G4=0x36, H4=0x37,
  A5=0x40, B5=0x41, C5=0x42, D5=0x43, E5=0x44, F5=0x45, G5=0x46, H5=0x47,
  A6=0x50, B6=0x51, C6=0x52, D6=0x53, E6=0x54, F6=0x55, G6=0x56, H6=0x57,
  A7=0x60, B7=0x61, C7=0x62, D7=0x63, E7=0x64, F7=0x65, G7=0x66, H7=0x67,
  A8=0x70, B8=0x71, C8=0x72, D8=0x73, E8=0x74, F8=0x75, G8=0x76, H8=0x77
};

/* Types of central pawn structure: */
enum {UNKNOWN, OPEN, HALF_OPEN, CLOSED, HALF_CLOSED, TENSION, UNRESOLVED};

/* Endgames with special evaluation functions: */
enum {KXK=1, KPK=2, KRKB=3, KRKN=4, KRKP=5, KBNK=6, KRPKR=7, KQKR=8};

#define W_OO_MASK 1
#define W_OOO_MASK 2
#define B_OO_MASK 4
#define B_OOO_MASK 8

#define OO_POSSIBLE(side) ((Pos.castle_flags&(1<<((side)*2)))==0)
#define OOO_POSSIBLE(side) ((Pos.castle_flags&(1<<((side)*2+1)))==0)

#define PROHIBIT_OO(side) Pos.castle_flags |= (1<<((side)*2))
#define PROHIBIT_OOO(side) Pos.castle_flags |= (1<<((side)*2+1))

#define PROHIBIT_WHITE_OO() Pos.castle_flags |= W_OO_MASK
#define PROHIBIT_WHITE_OOO() Pos.castle_flags |= W_OOO_MASK
#define PROHIBIT_BLACK_OO() Pos.castle_flags |= B_OO_MASK
#define PROHIBIT_BLACK_OOO() Pos.castle_flags |= B_OOO_MASK

/* FRC stuff: */
#define CASTLING(m) ((m)&CASTLE_FLAG)
#define SHORT_CASTLING(m) (CASTLING(m) && file(TO(m))==FILE_G)
#define LONG_CASTLING(m) (CASTLING(m) && file(TO(m))==FILE_C)


/***************************************************************************
 *                                Types                                    *
 ***************************************************************************/

typedef signed char int8;
typedef unsigned char uint8;
typedef signed short int16;
typedef unsigned short uint16;
typedef signed long int32;
typedef unsigned long uint32;
typedef signed long long int64;
typedef unsigned long long uint64;

typedef uint64 hashkey_t;

typedef struct {
  uint8 p, n;
} list_t;

typedef struct {
  uint8 board_[256];
  uint8 *board;
  list_t piece_list[256];
  int ep_square;
  int castle_flags;
  int rule50;
  int side, xside;
  hashkey_t key;
  hashkey_t pkey;
  hashkey_t previous_keys[MAX_GAME_LENGTH];
} position_t;

typedef uint32 move_t;

typedef struct {
  move_t move;
  int score;
} move_stack_t;

typedef struct {
  hashkey_t key, pkey;
  int ep_square, rule50, castle_flags;
} undo_info_t;

typedef struct {
  int king_safety[2];
  int passed_pawns[2];
} eval_vector_t;  

typedef struct {
  move_stack_t *ms_ptr;
  move_t pv[MAX_DEPTH];
  move_t move;
  move_t killer, killer2, mate_killer;
  move_t threat_move;
  undo_info_t undo_info;
  int material[2];
  int psq[2];
  int inceval;
  int eval;
  int evaluated;
  eval_vector_t eval_vector;
  int pawns[2];
  int check;
  int checkers[2];
  int num_of_evasions;
  int extension;
  int ext_reason;
  int reduction;
  int last_moved_piece_hanging;
  int moves_picked;
} search_stack_t;

typedef struct {
  uint8 may_attack;
  int8 step;
} attack_data_t;

typedef struct {
  hashkey_t key;
  int16 score[2];
  int16 e_score[2];
  uint8 passed_pawn_squares[2][8];
  uint8 outpost_squares[2][8];
  uint8 open_files[2];
  int8 k_storm[2];
  int8 q_storm[2];
  uint8 space[2];
  uint8 centre;
} p_hashentry_t;

typedef struct {
  int aggressiveness;
  int cowardice;
  int ks_weight[2];
  int pp_weight;
  int ps_weight;
  int mob_weight;
  int e_mob_weight;
  int space_weight;
  int development_weight;
  int own_book;
  int use_eval_cache;
  int eval_cache_size;
  int static_pruning;
  int pruning_depth;
  int qs_checks;
  int ponder;
  int frc;
  int currline;
  int multipv;
  int analyse;
  int learning;
} engine_options_t;

typedef struct {
  move_t move;
  unsigned score;
  unsigned factor;
} bookentry_t;

typedef struct {
  FILE *file;
  int found, is_active, size;
  hashkey_t first_key, last_key;
} book_t;

#define MAX_ROOT_MOVES 512

typedef struct {
  move_t move;
  int depth_1_score, score, score_type, depth;
  move_t pv[MAX_DEPTH];
  uint64 nodes, cumulative_nodes;
} root_move_t;

typedef struct {
  root_move_t moves[MAX_ROOT_MOVES];
  int num;
  int current;
} root_move_list_t;

typedef struct {
  root_move_list_t root_moves;
  int node_limit;
  int depth_limit;
  int exact_time;
  int max_time;
  int absolute_max_time;
  int infinite;
  int thinking_status;
  int start_time;
  move_t pv[MAX_DEPTH];
  move_t bestmove, pondermove, easymove;
  int iteration;
  int bestvalues[MAX_DEPTH];
  int problem;
  int fail_high;
  int mate_found;
  uint64 nodes;
  int nodes_between_polls;
  int nodes_since_poll;
  int max_depth;
  move_t search_moves[MAX_ROOT_MOVES];
} root_search_info_t;

/***************************************************************************
 *                              Variables                                  *
 ***************************************************************************/

extern position_t Pos;

extern uint32 FileMask[8];

extern int Directions[16][16];
extern int SlidingArray[16];
extern int PawnPush[2];
extern uint8 PawnRank[2][128];
extern attack_data_t AttackData_[256];
extern attack_data_t *AttackData;
extern int PieceMask[OUTSIDE+1];
extern uint8 Distance_[256];
extern uint8 *Distance;
extern uint8 SquareColour[128];
extern int KingActivityBonus[256];

extern move_stack_t MoveStack[MOVE_STACK_SIZE];
extern search_stack_t SearchStack[MAX_DEPTH];
extern int Ply, GPly;

extern int8 PSqTables[BK+1][128];
extern int8 KingEndgamePsq[128];
extern int PieceValues[EMPTY+1];

extern uint32 History[2][4096];

extern hashkey_t Zobrist[BK][64];
extern hashkey_t ZobColour;
extern hashkey_t ZobEP[64];
extern hashkey_t ZobCastle[16];

extern root_search_info_t RootSearchInfo;

extern engine_options_t EngineOptions;

extern book_t Book[1];

/* FRC stuff: */
extern int InitialKSQ, InitialKRSQ, InitialQRSQ;

/***************************************************************************
 *                              Functions                                  *
 ***************************************************************************/

extern void init(void);

extern void init_board(void);
extern void init_piece_lists(void);
extern void copy_position(position_t *, position_t *);

extern char *move2str(move_t, char *);
extern void print_move(move_t);
extern void print_pv(move_t *, int, int, int);
extern void print_multipv(void);
extern void print_currline(void);
extern void set_position(char *);
extern void quit(void);
extern move_t parse_move(char *);
extern int parse_square(char *);
extern void check_for_input(void);
extern int get_time(void);

extern int extend(move_t, int *, int *, int, int);

extern void init_search(void);
extern void init_node(void);
extern void update_pv(move_t);
extern int search(int, int, int, int, int);
extern int qsearch(int, int, int, int, int);

extern int swabbing(int, int);
extern int global_swabbing(int, int);

extern void think(int, int, int, int, int, int, int, int, int, int, move_t *);

extern void init_root_search_info(void);
extern void root_search(move_t *);
extern void ponderhit(void);

extern void generate_moves(void);
extern void generate_captures(void);
extern void generate_check_evasions(void);
extern void generate_checks(void);

extern int is_attacked(int, int);
extern int in_check(int);
extern int fast_in_check(void);
extern int find_checkers(int[]);
extern int fast_find_checkers(int[]);
extern int pinned(int);
extern int disc_check_candidate(int);

extern int irreversible(move_t);
extern int is_legal(move_t);
extern int is_check(move_t);
extern int pawn_push_to_7th(move_t);
extern int pawn_push_to_6th(move_t);
extern void make_move(move_t);
extern void unmake_move(move_t);
extern void make_nullmove(void);
extern void unmake_nullmove(void);

extern int compute_material(int);
extern int compute_psq(int);
extern int count_pawns(int);
extern void init_eval_cache();
extern int evaluate(void);
extern int approx_eval_after_move(move_t);
extern int draw(void);

extern int attacked_by_non_king(int, int);
extern void init_safety(void);
extern int evaluate_king_safety(int, int, int);

extern int mate_lone_king(int);
extern int pawn_endgame(void);
extern int scale_endgame_eval(int* , p_hashentry_t*);
extern void init_kpk(void);
extern int kxk_eval(void);
extern int kpk_eval(void);
extern int krkb_eval(void);
extern int krkn_eval(void);
extern int krkp_eval(void);
extern int kbnk_eval(void);
extern int krpkr_eval(void);
extern int kqkr_eval(void);

extern void order_moves(move_t);
extern void order_qmoves(move_t);
extern move_t pick_move(void);

extern void clear_history(void);
extern void inc_history(move_t, int, int, int);

extern void init_zobrist(void);
extern hashkey_t compute_hash_key(void);
extern hashkey_t compute_phash_key(void);

extern void free_tt(void);
extern void clear_tt(void);
extern void init_tt(int);
extern void store_tt(int, int, move_t, int, int);
extern int retrieve_tt(int *, int *, int, move_t *, int *, int *);
extern void tt_new_search(void);

extern void init_pawn_hash_table(void);
extern void free_pawn_hash_table(void);
extern p_hashentry_t *analyse_pawn_structure(void);

extern void init_mersenne(void);
extern uint32 genrand_int32(void);
extern uint64 genrand_int64(void);

extern void define_uci_options(void);
extern void print_uci_options(void);
extern int get_option_value_bool(const char *);
extern int button_was_pushed(const char *);
extern int get_option_value_int(const char *);
extern char *get_option_value_string(const char *, char *);
extern void set_option_value(const char *, const char *);
extern void push_button(const char *);

extern void uci_main_loop(void);

extern int init_book(book_t *, char *);
extern void close_book(book_t *);
extern void activate_book(book_t *);
extern void deactivate_book(book_t *);
extern move_t pick_book_move(book_t *, hashkey_t);

extern void clear_learning(void);
extern void init_learning(void);
extern void save_learning(void);
extern void store_learning_data(hashkey_t, move_t, move_t, int, int, int);
extern int get_learning_data(hashkey_t, int, move_t *, move_t *, int *);
extern int get_learning_data_at_root(hashkey_t, int, move_t *, move_t *);

#undef CDECL
#ifdef _MSC_VER
#define llu_format  "%I64u"
extern int      gettimeofday(struct timeval * , struct timezone * );
#define CDECL __cdecl
#else
#define llu_format  "%llu"
#define CDECL
#endif

