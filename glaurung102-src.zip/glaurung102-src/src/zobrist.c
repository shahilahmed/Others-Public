#include "glaurung.h"

hashkey_t Zobrist[BK][64];
hashkey_t ZobColour;
hashkey_t ZobEP[64];
hashkey_t ZobCastle[16];

void init_zobrist(void) {
  int i, j;

  for(i=0; i<BK; i++)
    for(j=0; j<64; j++)
      Zobrist[i][j] = genrand_int64();
  ZobEP[0] = 0;
  for(i=1; i<64; i++) ZobEP[i] = genrand_int64();
  for(i=0; i<16; i++) ZobCastle[i] = genrand_int64();
  ZobColour = genrand_int64();
}

hashkey_t compute_hash_key(void) {
  hashkey_t result = 0;
  int side, sq;

  for(side=WHITE; side<=BLACK; side++) 
    for(sq=KSQ(side); sq!=PL_END; sq=PL_NEXT(sq)) {
      if(sq<=H8) result^=ZOBRIST(Board[sq], sq);
    }
  result^=ZOB_EP(Pos.ep_square);
  result^=ZOB_CASTLE(Pos.castle_flags);
  if(Side==BLACK) result^=ZobColour;
  return result;
}

hashkey_t compute_phash_key(void) {
  hashkey_t result = 0;
  int side, sq;

  for(side=WHITE; side<=BLACK; side++) 
    for(sq=PL_START((side<<3)|PAWN); sq<=H8; sq=PL_NEXT(sq))
      result^=ZOBRIST(Board[sq], sq);
  return result;
}
