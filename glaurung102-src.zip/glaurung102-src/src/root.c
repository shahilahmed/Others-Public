#include "glaurung.h"

static void add_root_move(move_t move, root_move_list_t *list) {
  if(is_legal(move)) {
    list->moves[list->num].move = move;
    list->moves[list->num].nodes = 0;
    list->moves[list->num].cumulative_nodes = 0;
    make_move(move);
    list->moves[list->num].depth_1_score = 
      -qsearch(-MATE_VALUE-1, MATE_VALUE+1, 0, 0, 0);
    list->moves[list->num].score = -MATE_VALUE-1;
    unmake_move(move);
    list->num++;
  }
}

static move_t scan_for_easy_move(root_move_list_t *list) {
  int best_move_score = list->moves[0].depth_1_score;
  int i;
  for(i = 1; i < list->num; i++)
    if(list->moves[i].depth_1_score >= best_move_score - P_VALUE) return 0;
  return list->moves[0].move;
}

static int CDECL key1(const void *a, const void *b) {
  if(((root_move_t*)a)->move == RootSearchInfo.pv[0]) return -1;
  else if(((root_move_t*)b)->move == RootSearchInfo.pv[0]) return 1;
  else if(((root_move_t*)a)->depth_1_score > ((root_move_t*)b)->depth_1_score)
    return -1; 
  else 
    return 1;
}

static int CDECL key2(const void *a, const void *b) {
  if(((root_move_t*)a)->move == RootSearchInfo.pv[0]) return -1;
  else if(((root_move_t*)b)->move == RootSearchInfo.pv[0]) return 1;
  else if(((root_move_t*)a)->nodes > ((root_move_t*)b)->nodes)
    return -1; 
  else
    return 1;
}

static int CDECL key3(const void *a, const void *b) {
  if(((root_move_t*)a)->depth > ((root_move_t*)b)->depth &&
     ((root_move_t*)a)->score_type == EXACT) return -1;
  else if(((root_move_t*)b)->depth > ((root_move_t*)a)->depth &&
          ((root_move_t*)b)->score_type == EXACT) return 1;
  else if(((root_move_t*)a)->score > ((root_move_t*)b)->score) return -1;
  else if(((root_move_t*)b)->score > ((root_move_t*)a)->score) return 1;
  else if(((root_move_t*)a)->nodes > ((root_move_t*)b)->nodes) return -1; 
  else return 1;
}

static void sort_root_moves(root_move_list_t *list, int iteration) {
  if(iteration <= 2) 
    qsort(list->moves, list->num, sizeof(root_move_t), key1);
  else if(EngineOptions.multipv == 1 || list->num == 1)
    qsort(list->moves, list->num, sizeof(root_move_t), key2);
  else 
    qsort(list->moves, list->num, sizeof(root_move_t), key3);
  list->current = 0;
  RootSearchInfo.pv[0] = list->moves[0].move; RootSearchInfo.pv[1] = 0;
}

static move_t pick_root_move(root_move_list_t *list) {
  if(list->current == list->num) return 0;
  return list->moves[list->current++].move;
}

static void remember_node_count(uint64 nodes, root_move_list_t *list) {
  list->moves[list->current - 1].nodes = nodes;  
  list->moves[list->current - 1].cumulative_nodes += nodes;
}

static void update_root_pv(void) {
  int i;
  for(i=0; SearchStack[0].pv[i]; i++) 
    RootSearchInfo.pv[i] = SearchStack[0].pv[i];
  RootSearchInfo.pv[i] = 0;
  RootSearchInfo.bestmove = RootSearchInfo.pv[0];
  RootSearchInfo.pondermove = RootSearchInfo.pv[1];
}

void init_root_search_info(void) {
  RootSearchInfo.start_time = get_time();
  RootSearchInfo.iteration = 1;
  RootSearchInfo.easymove = 0;
  RootSearchInfo.bestmove = 0;
  RootSearchInfo.pondermove = 0;
  RootSearchInfo.problem = 0;
  RootSearchInfo.mate_found = 0;
  RootSearchInfo.nodes = 0;
  RootSearchInfo.nodes_since_poll = 0;
  RootSearchInfo.max_depth = 0;
  RootSearchInfo.pv[0] = 0; RootSearchInfo.pv[1] = 0;
  RootSearchInfo.root_moves.num = 0;
}

void root_search(move_t searchmoves[]) {
  int value=0, lastvalue = -MATE_VALUE-1, bestvalue, alpha, beta;
  int depth, ext, i, index;
  uint64 nodes;
  search_stack_t *ss = SearchStack;
  move_t move;

  init_search();
  init_node();
  if(ss->check) generate_check_evasions(); else generate_moves();
  order_moves(0);

  if(searchmoves[0] == 0)
    while((move = pick_move())) 
      add_root_move(move, &RootSearchInfo.root_moves);
  else {
    for(i = 0; searchmoves[i] != 0; i++) 
      add_root_move(searchmoves[i], &RootSearchInfo.root_moves);
  }

  do {
    RootSearchInfo.problem = 0;
    RootSearchInfo.iteration++;
    if(RootSearchInfo.iteration <= 60) 
      printf("info depth %d seldepth %d\n", RootSearchInfo.iteration,
             max(RootSearchInfo.iteration, RootSearchInfo.max_depth));
    alpha = -MATE_VALUE-1; beta = MATE_VALUE+1;

    depth = RootSearchInfo.iteration * PLY;
    init_node();

    bestvalue = -MATE_VALUE-1;
    sort_root_moves(&RootSearchInfo.root_moves, RootSearchInfo.iteration);
    if(RootSearchInfo.iteration == 2)
      RootSearchInfo.easymove = scan_for_easy_move(&RootSearchInfo.root_moves);

    while((move = pick_root_move(&RootSearchInfo.root_moves))) {
      if(is_legal(move)) {
        if(RootSearchInfo.iteration > 1 && 
           get_time()-RootSearchInfo.start_time > 1000) {
          printf("info currmove "); print_move(move);
          printf("currmovenumber %d\n", RootSearchInfo.root_moves.current);
        }

        nodes = RootSearchInfo.nodes;

        make_move(move);
        ext = extend(move, &(ss->extension), &(ss->ext_reason), 0, 0);
        
        if(RootSearchInfo.root_moves.current <= EngineOptions.multipv) {
          RootSearchInfo.fail_high = 0;
          alpha = -MATE_VALUE - 1;
	  if(RootSearchInfo.root_moves.current == 1) 
	    value = -search(-beta, -alpha, depth-PLY+ext, 1, 1);
	  else
	    value = -search(-beta, -alpha, depth-PLY+ext, 0, 1);
          RootSearchInfo.problem = (value <= lastvalue - 40);
        }
        else {
          RootSearchInfo.fail_high = 0;
          value = -search(-alpha-1, -alpha, depth-PLY+ext, 0, 1);
          if(value > alpha && value < beta && 
             RootSearchInfo.thinking_status != ABORTED) {
            RootSearchInfo.fail_high = 1;
            value = -search(-beta, -alpha, depth-PLY+ext, 0, 1);
          }
        }
        unmake_move(move);

        remember_node_count(RootSearchInfo.nodes-nodes, 
                            &RootSearchInfo.root_moves);

        if(RootSearchInfo.thinking_status == ABORTED) break;
	index = RootSearchInfo.root_moves.current - 1;

	RootSearchInfo.root_moves.moves[index].pv[0] = move;
	for(i = 1; SearchStack[1].pv[i]; i++)
	  RootSearchInfo.root_moves.moves[index].pv[i] = SearchStack[1].pv[i];
	RootSearchInfo.root_moves.moves[index].pv[i] = 0;

        if(value <= alpha) {
          RootSearchInfo.root_moves.moves[index].score = -MATE_VALUE - 1;
          RootSearchInfo.root_moves.moves[index].score_type = UPPER_BOUND;
          RootSearchInfo.root_moves.moves[index].depth = 
	    RootSearchInfo.iteration;
        }
        else {
          RootSearchInfo.root_moves.moves[index].score = value;
          RootSearchInfo.root_moves.moves[index].score_type = EXACT;
          RootSearchInfo.root_moves.moves[index].depth = RootSearchInfo.iteration;
          alpha = value;

          if(value > bestvalue) {
            bestvalue = value;
            update_pv(move); update_root_pv();
            if(bestvalue > lastvalue - 20) RootSearchInfo.problem = 0;
          }
          if(EngineOptions.multipv == 1) 
            print_pv(RootSearchInfo.pv, RootSearchInfo.iteration, value, 1);
          else {
            qsort(RootSearchInfo.root_moves.moves, RootSearchInfo.root_moves.num,
                  sizeof(root_move_t), key3);
            print_multipv();
          }
        }
      }
    }
    if(RootSearchInfo.thinking_status == ABORTED) break;
    if(abs(bestvalue) >= MATE_VALUE - 200) RootSearchInfo.mate_found++;

    /* Stop searching when there is only a single legal move: */
    if(RootSearchInfo.iteration >= 5 && RootSearchInfo.root_moves.num == 1 &&
       !RootSearchInfo.infinite && RootSearchInfo.thinking_status != PONDERING)
      break;

    /* Stop searching when the last two iterations returned a mate score: */
    if(RootSearchInfo.iteration >= 3 && RootSearchInfo.mate_found >= 2 && 
       !RootSearchInfo.infinite && RootSearchInfo.thinking_status != PONDERING)
        break;

    if(RootSearchInfo.pv[0] != RootSearchInfo.easymove) 
      RootSearchInfo.easymove = 0;

    /* Stop search early if one move seems much better than the rest: */
    if(RootSearchInfo.iteration >= 5 && RootSearchInfo.easymove &&
       ((RootSearchInfo.root_moves.moves[0].cumulative_nodes > 
         (RootSearchInfo.nodes*85)/100 &&
         get_time() - RootSearchInfo.start_time > RootSearchInfo.max_time/16) ||
        (RootSearchInfo.root_moves.moves[0].cumulative_nodes > 
         (RootSearchInfo.nodes*99)/100 &&
         get_time()-RootSearchInfo.start_time > RootSearchInfo.max_time/32)) &&
       !RootSearchInfo.infinite && RootSearchInfo.thinking_status!=PONDERING) {
      break;
    }

    /* Stop search if most of RootSearchInfo.max_time is consumed at the end
     * of the iteration.  We probably don't have enough time to search the
     * first move at the next iteration anyway.  */
    if(get_time() - RootSearchInfo.start_time > 
       (RootSearchInfo.max_time*80)/128 &&
       !RootSearchInfo.infinite && RootSearchInfo.thinking_status!=PONDERING) {
      break;
    }
    lastvalue = bestvalue;
    if(RootSearchInfo.iteration < MAX_DEPTH)
      RootSearchInfo.bestvalues[RootSearchInfo.iteration] = bestvalue;
    if(RootSearchInfo.depth_limit && 
       RootSearchInfo.iteration >= RootSearchInfo.depth_limit) break;
    if(EngineOptions.learning)
      store_learning_data(Pos.key, 
                          RootSearchInfo.bestmove, RootSearchInfo.pondermove, 
                          get_time() - RootSearchInfo.start_time,
                          RootSearchInfo.iteration, 
                          bestvalue);
  } while(RootSearchInfo.thinking_status != ABORTED);
}

void ponderhit(void) {
  int t;
  if(!RootSearchInfo.infinite) {
    t = get_time() - RootSearchInfo.start_time;
    if((RootSearchInfo.iteration >= 2 && RootSearchInfo.root_moves.num == 1) ||
       (RootSearchInfo.mate_found >= 2) ||
       (t > RootSearchInfo.absolute_max_time) ||
       (t > RootSearchInfo.max_time &&
        (RootSearchInfo.root_moves.current == 1 || !RootSearchInfo.problem)) ||
       (t > RootSearchInfo.max_time/16 && RootSearchInfo.iteration >= 5 &&
        RootSearchInfo.easymove && 
        RootSearchInfo.root_moves.moves[0].cumulative_nodes > 
        (RootSearchInfo.nodes*85)/100) ||
       (t > RootSearchInfo.max_time/32 && RootSearchInfo.iteration >= 5 &&
        RootSearchInfo.easymove && 
        RootSearchInfo.root_moves.moves[0].cumulative_nodes >
        (RootSearchInfo.nodes*99)/100))
      RootSearchInfo.thinking_status = ABORTED;
    else
      RootSearchInfo.thinking_status = PONDERHIT;
  }
}
