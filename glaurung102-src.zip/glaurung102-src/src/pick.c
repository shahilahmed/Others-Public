#include "glaurung.h"

move_t pick_move(void) {
  move_stack_t *start, *end, *ms, tmp, *best=NULL;
  int best_score = -10000000;
  search_stack_t *ss = SearchStack+Ply;

  start = ss->ms_ptr + ss->moves_picked; end = (ss+1)->ms_ptr;
  if(start >= end) return 0;
  else if(ss->moves_picked >= 16) {
    ss->moves_picked++;
    return start->move;
  }
  for(ms=start; ms<end; ms++) {
    if(ms->score > best_score) {
      best = ms; best_score = best->score;
    }
  }
  if(best != NULL) {
    tmp = *start;
    *start = *best;
    *best = tmp;
    ss->moves_picked++;
    return start->move;
  }
  else return 0;
}
