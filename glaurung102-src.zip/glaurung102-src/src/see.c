#include "glaurung.h"

/*
   swabbing() is a static exchange evaluator.  It tries to estimate the
   gain or loss in material when a move is made.  The function does not
   yet understand pawn promotions.
*/
int swabbing(int from, int to) {
  int piece, capture, side, piece_val, val, step, sq, sq2, c;
  int attackers[2][16], num_of_attackers[2], swaplist[32], n, i;
  attack_data_t *a = AttackData-to;

  /* Find attackers for both sides.  The capturing piece is not added 
   * to the attack list.  Instead, we scan for X-ray attacks behind the
   * capturing piece. */

  num_of_attackers[WHITE] = num_of_attackers[BLACK] = 0;
  /* X-ray attacks through the moving piece: */
  if(a[from].may_attack & Q_MASK) { 
    step = a[from].step;
    for(sq=from-step; Board[sq]==EMPTY; sq-=step);
    if(PieceMask[Board[sq]]&a[sq].may_attack) {
      c = COLOUR(Board[sq]);
      attackers[c][num_of_attackers[c]++] = sq;
    }
  }

  /* Pawns: */
  if(Board[to-17]==WP && to-17!=from) 
    attackers[WHITE][num_of_attackers[WHITE]++] = to-17;
  if(Board[to-15]==WP && to-15!=from) 
    attackers[WHITE][num_of_attackers[WHITE]++] = to-15;
  if(Board[to+17]==BP && to+17!=from) 
    attackers[BLACK][num_of_attackers[BLACK]++] = to+17;
  if(Board[to+15]==BP && to+15!=from) 
    attackers[BLACK][num_of_attackers[BLACK]++] = to+15;

  /* Knights: */
  for(sq=PL_START(WN); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & N_MASK))
      attackers[WHITE][num_of_attackers[WHITE]++] = sq;
  for(sq=PL_START(BN); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & N_MASK))
      attackers[BLACK][num_of_attackers[BLACK]++] = sq;

  /* Bishops: */
  for(sq=PL_START(WB); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & B_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[WHITE][num_of_attackers[WHITE]++] = sq;
    }
  for(sq=PL_START(BB); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & B_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[BLACK][num_of_attackers[BLACK]++] = sq;
    }
  
  /* Rooks: */
  for(sq=PL_START(WR); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & R_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[WHITE][num_of_attackers[WHITE]++] = sq;
    }
  for(sq=PL_START(BR); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & R_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[BLACK][num_of_attackers[BLACK]++] = sq;
    }

  /* Queens: */
  for(sq=PL_START(WQ); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & Q_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[WHITE][num_of_attackers[WHITE]++] = sq;
    }
  for(sq=PL_START(BQ); sq<=H8; sq=PL_NEXT(sq)) 
    if(sq!=from && (a[sq].may_attack & Q_MASK)) {
      step = a[sq].step;
      for(sq2=sq+step; Board[sq2]==EMPTY && sq2!=to; sq2+=step);
      if(sq2==to) attackers[BLACK][num_of_attackers[BLACK]++] = sq;
    }

  /* Kings: */
  sq = KSQ(WHITE);
  if(sq!=from && (a[sq].may_attack & K_MASK)) 
    attackers[WHITE][num_of_attackers[WHITE]++] = sq;
  sq = KSQ(BLACK);
  if(sq!=from && (a[sq].may_attack & K_MASK)) 
    attackers[BLACK][num_of_attackers[BLACK]++] = sq;
     
  /* Compute swap list. */
  piece = Board[from]; capture = Board[to]; side = COLOUR(piece)^1;
  piece_val = PieceValues[piece]; val = PieceValues[capture];

  swaplist[0] = val; n = 1;
  while(num_of_attackers[side] > 0) {
    /* Locate smallest attacker for side to move. */
    int smallest_value = K_VALUE+1;
    int index = 0; 
    for(i=0; i<num_of_attackers[side]; i++) {
      val = PieceValues[Board[attackers[side][i]]];
      if(val < smallest_value) {
        smallest_value = val;
        index = i;
      }
    }
    sq = attackers[side][index];
    attackers[side][index] = attackers[side][--num_of_attackers[side]];

    /* sq now contains the square of the smallest attacker, and
     * smallest_value contains its value.  Now, scan for new X-ray
     * attacks, and add them to the attackers list: */
    if(a[sq].may_attack & Q_MASK) {
      step = a[sq].step;
      for(sq2=sq-step; Board[sq2]==EMPTY; sq2-=step);
      if(PieceMask[Board[sq2]]&a[sq2].may_attack) {
        c = COLOUR(Board[sq2]);
        attackers[c][num_of_attackers[c]++] = sq2;
      }
    }

    /* Stop after a king capture: */
    if(piece_val==K_VALUE) { swaplist[n]=K_VALUE; n++; break; }

    /* Add the new entry to swaplist: */
    swaplist[n] = -swaplist[n-1]+piece_val; n++;
    piece_val = smallest_value;
    
    side^=1;
  }

  while(--n)
    swaplist[n-1] = min(-swaplist[n], swaplist[n-1]);

  return swaplist[0];
}

/*
   global_swabbing is a limited full board swapoff function.  It returns
   a nonzero value if the given side has a pawn on the 7th rank or a capture
   which appears to win at least the amount of material given by the 
   min_value parameter.
*/
int global_swabbing(int side, int min_value) {
  int from, to, piece,  xside=side^1;
  int *ptr;

  if(min_value <= 0) return 1;

  min_value *= 2;

  /* Pawns. */
  piece = ((side<<3)|PAWN);
  for(from=PL_START(piece); from<=H8; from=PL_NEXT(from)) {
    if(PawnRank[side][from]==RANK_7) return 1;
    for(ptr=Directions[piece]; *ptr; ptr++) {
      to = from + (*ptr);
      if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) {
        if(PieceValues[Board[to]]-P_VALUE >= min_value) return 1;
        else if(swabbing(from, to) >= min_value) return 1;
      }
    }
  }

  /* Knights. */
  piece++;
  for(from=PL_START(piece); from<=H8; from=PL_NEXT(from)) {
    for(ptr=Directions[piece]; *ptr; ptr++) {
      to = from + (*ptr);
      if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) {
        if(PieceValues[Board[to]]-N_VALUE >= min_value) return 1;
        else if(swabbing(from, to) >= min_value) return 1;
      }
    }
  }

  /* Bishops. */
  piece++;
  for(from=PL_START(piece); from<=H8; from=PL_NEXT(from)) {
    for(ptr=Directions[piece]; *ptr; ptr++) {
      for(to = from + (*ptr); Board[to]==EMPTY; to += (*ptr));
      if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) {
        if(PieceValues[Board[to]]-B_VALUE >= min_value) return 1;
        else if(swabbing(from, to) >= min_value) return 1;
      }
    }
  }

  /* Rooks. */
  piece++;
  for(from=PL_START(piece); from<=H8; from=PL_NEXT(from)) {
    for(ptr=Directions[piece]; *ptr; ptr++) {
      for(to = from + (*ptr); Board[to]==EMPTY; to += (*ptr));
      if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) {
        if(PieceValues[Board[to]]-R_VALUE >= min_value) return 1;
        else if(swabbing(from, to) >= min_value) return 1;
      }
    }
  }

  /* Queens. */
  piece++;
  for(from=PL_START(piece); from<=H8; from=PL_NEXT(from)) {
    for(ptr=Directions[piece]; *ptr; ptr++) {
      for(to = from + (*ptr); Board[to]==EMPTY; to += (*ptr));
      if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) 
        if(swabbing(from, to) >= min_value) return 1;
    }
  }

  /* King. */
  piece++;
  from=PL_START(piece);
  for(ptr=Directions[piece]; *ptr; ptr++) {
    to = from + (*ptr);
    if(PieceValues[Board[to]] >= min_value && COLOUR(Board[to])==xside) 
      if(!is_attacked(to, xside)) return 1;
  }

  return 0;
}

