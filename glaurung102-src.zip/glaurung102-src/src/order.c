#include "glaurung.h"

void order_moves(move_t pvmove) {
  move_stack_t *ms;
  move_t m;
  int cap, pc, from, to;

  SearchStack[Ply].moves_picked = 0;
  for(ms=SearchStack[Ply].ms_ptr; ms<SearchStack[Ply+1].ms_ptr; ms++) {
    m = ms->move;
    if((ms->move&0x1FFFF) == (pvmove&0x1FFFF)) {
      if(TO(m) == TO(SearchStack[Ply-1].move)) {
        int s = swabbing(FROM(m), TO(m));
        if(s > 0) 
          SearchStack[Ply].last_moved_piece_hanging = 1;
      }
      ms->score = 100000000; continue;
    }
    if(ms->move == SearchStack[Ply].mate_killer) {
      ms->score = 99999999; continue;
    }
    cap = CAPTURE(m); pc = PIECE(m); from = FROM(m); to = TO(m);
    if(PROMOTION(m) == QUEEN && swabbing(from, to) >= 0) {
      ms->score = 10000000 + cap; continue;
    }
    if(cap) {
      int s = swabbing(from, to);
      if(Ply > 0 && s > 0 && to == TO(SearchStack[Ply-1].move)) {
        SearchStack[Ply].last_moved_piece_hanging = 1;
        ms->score = 10000000 + s;
      }
      else if(s >= 0) ms->score = 9000000 + s;
      else ms->score = s;
    }
    else if(ms->move==SearchStack[Ply].killer)
      ms->score = 9000000;
    else if(ms->move==SearchStack[Ply].killer2)
      ms->score = 8999999;
    else if(Ply >= 2 && ms->move==SearchStack[Ply-2].killer)
      ms->score = 8999998;
    else if(Ply >= 2 && ms->move==SearchStack[Ply-2].killer2)
      ms->score = 8999997;
    else ms->score = HISTORY(Side, m);
  }
}

void order_qmoves(move_t pvmove) {
  move_stack_t *ms;
  move_t m;
  int cap, pc, from, to;

  SearchStack[Ply].moves_picked = 0;
  if(SearchStack[Ply].check) order_moves(pvmove);
  else {
    for(ms=SearchStack[Ply].ms_ptr; ms<SearchStack[Ply+1].ms_ptr; ms++) {
      m = ms->move;
      if(ms->move == pvmove) {
        ms->score = 100000000;
        continue;
      }
      cap = CAPTURE(m); pc = PIECE(m); from = FROM(m); to = TO(m);
      if(PROMOTION(m) == QUEEN && swabbing(from, to) >= 0) {
        ms->score = 10000000 + cap; continue;
      }
      if(cap) {
        if(Ply>0 && to==TO(SearchStack[Ply-1].move))
          ms->score = 10000000 - pc;
        else ms->score = 9000000 + PieceValues[cap] - pc;
      }
      else ms->score = 0;
    }
  }
}

