#include "glaurung.h"

int compute_material(int side) {
  int sq, result=0;
  for(sq=PL_NEXT(KSQ(side)); sq!=PL_END; sq=PL_NEXT(sq)) 
    if(sq<=H8) result+=PieceValues[Board[sq]];
  return result;
}

int compute_psq(int side) {
  int sq, result=0;
  for(sq=PL_NEXT(KSQ(side)); sq!=PL_END; sq=PL_NEXT(sq)) 
    if(sq<=H8) result+=PSQ(Board[sq], sq);
  return result;
}

int count_pawns(int side) {
  int sq, result=0;
  for(sq=PL_START((side<<3)|PAWN); sq<=H8; sq=PL_NEXT(sq)) 
    result++;
  return result;
}

#define KEY_MASK ((1ULL<<48)-1)

typedef struct {
  uint64 key_and_score;
  int16 safety[2];
  int16 ppawns[2];
} eval_hashentry_t;

eval_hashentry_t *EvalCache = NULL;
int EvalCacheSize = 0;

void free_eval_cache(void) {
  EvalCacheSize = 0;
  free(EvalCache);
  EvalCache = NULL;
}

void init_eval_cache(void) {
  int s, new_size;

  if(EngineOptions.use_eval_cache) {
    s = EngineOptions.eval_cache_size << 16;
    for(new_size=(1<<17); new_size <= s; new_size*=2);
    new_size /= 2;
    if(new_size != EvalCacheSize) {
      free_eval_cache();
      EvalCacheSize = new_size;
      EvalCache = malloc(EvalCacheSize * sizeof(eval_hashentry_t));
      memset(EvalCache, 0, EvalCacheSize * sizeof(eval_hashentry_t));
    }
  }
  else free_eval_cache();
}

static inline int retrieve_eval(int *score, int safety[2], int pp[2]) {
  int index = (Pos.key & (EvalCacheSize - 1));
  if((EvalCache[index].key_and_score & KEY_MASK) == (Pos.key & KEY_MASK)) {
    *score = (int16) (EvalCache[index].key_and_score >> 48);
    safety[WHITE] = EvalCache[index].safety[WHITE];
    safety[BLACK] = EvalCache[index].safety[BLACK];
    pp[WHITE] = EvalCache[index].ppawns[WHITE];
    pp[BLACK] = EvalCache[index].ppawns[BLACK];
    return 1;
  }
  return 0;
}

static inline void store_eval(int score, int safety[2], int pp[2]) {
  int index = (Pos.key & (EvalCacheSize - 1));
  EvalCache[index].key_and_score = 
    (Pos.key & KEY_MASK) | ((uint64)score << 48);
  EvalCache[index].safety[WHITE] = safety[WHITE];
  EvalCache[index].safety[BLACK] = safety[BLACK];
  EvalCache[index].ppawns[WHITE] = pp[WHITE];
  EvalCache[index].ppawns[BLACK] = pp[BLACK];
}


#define GRAIN_SIZE 4 /* Must be a power of 2 */

#define ROOK_OPEN_FILE_BONUS 30
#define EARLY_QUEEN_ACTIVITY 50
#define TRAPPED_ROOK 180
#define BISHOP_TRAPPED_A7H7 300
#define BISHOP_TRAPPED_A1H1 100
#define BLOCKING_CENTRAL_PAWN 45

#define TEMPO_BONUS_MIDGAME 40
#define TEMPO_BONUS_ENDGAME 10

int NMobBonus[9] = {
  -10, -4, 2, 8, 14, 18, 22, 24, 25
};

int BMobBonus[16] = {
  -20, -10, 0, 10, 20, 30, 38, 44, 48, 52, 54, 57, 58, 59, 60, 60
};

int RMobBonus[16] = {
  -12, -8, -4, 0, 4, 8, 11, 14, 16, 18, 19, 20, 21, 22, 23, 24
};

int RMobBonusEndgame[16] = {
  -20, -12, -4, 4, 12, 20, 28, 36, 44, 50, 54, 56, 57, 58, 59, 60
};

int QMobBonus[32] = {
  -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 10, 12, 13, 14, 15, 16,
  16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16
};

int QMobBonusEndgame[32] = {
  -20, -15, -10, -5, 0, 5, 10, 15, 19, 23, 27, 29, 30, 30, 30, 30,
  30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30
};

int DevelopmentPenalty[13] = {
  0, -4, -12, -20, -30, -40, -50, -60, -70, -80, -90, -100, -110
};

int MultiplePassivePenalty[8] = {0, 2, 6, 20, 50, 80, 120, 120};

int ShieldValue[2][32] = {
  {4, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0, 0, 0, 0, 4, 1, 2, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

uint8 SquareColour[128] = {
  1, 2, 1, 2, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
  2, 1, 2, 1, 2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 2, 1, 2, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
  2, 1, 2, 1, 2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 2, 1, 2, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
  2, 1, 2, 1, 2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 2, 1, 2, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0,
  2, 1, 2, 1, 2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0
};

/* Passed pawn bonus by rank: */
int PpBonus[8] = {0, 30, 30, 60, 100, 160, 256, 0};

/* King activity bonus, indexed by (square of king) - (square of pawn): */
int KingActivityBonus[256] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5,
  8, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 10,
  15, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 13, 22,
  25, 22, 13, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 20, 30, 
  0, 30, 20, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 25, 40, 
  40, 40, 25, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 22, 33,
  35, 33, 22, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 14, 22,
  22, 22, 14, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 7, 10,
  10, 10, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};

int RooksOn7thBonus[32] = {
  0, 16, 32, 64, 110, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
  150, 150, 150, 150, 150, 150, 150, 150,
  150, 150, 150, 150, 150, 150, 150, 150
};

int BishopPairBonus[7] = {
  60,  /* UNKNOWN */
  100, /* OPEN */
  80,  /* HALF_OPEN */
  0,   /* CLOSED */
  30,  /* HALF_CLOSED */
  70,  /* TENSION */
  60   /* UNRESOLVED */
};

int OutpostBonus[2][128] = {
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 5, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 10, 15, 15, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 15, 20, 20, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
  },
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 15, 20, 20, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 10, 15, 15, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 5, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
  }
};

int MobilityIncrement[2][64] = {
  {1, -1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
   1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
  {1, 1, 1, 1, 1, 1, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0,
   1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

int (*EndgameEvalFunction[KQKR])(void) = {
  kxk_eval, kpk_eval, krkb_eval, krkn_eval, krkp_eval, kbnk_eval, krpkr_eval,
  kqkr_eval
};

static inline int evaluate_pawn_shield(int side, int square) {
  int *shieldValue = ShieldValue[side];
  int result = 0, x = PawnPush[side];
  result += shieldValue[Board[square+x]-1];
  result += shieldValue[Board[square+x-1]-1];
  result += shieldValue[Board[square+x+1]-1];
  result += shieldValue[Board[square+2*x]-1]/2;
  result += shieldValue[Board[square+2*x-1]-1]/2;
  result += shieldValue[Board[square+2*x+1]-1]/2;
  return result;
}

int evaluate(void) {
  p_hashentry_t *ph = analyse_pawn_structure();
  search_stack_t *ss = SearchStack+Ply;
  int result = ss->inceval;
  int e_result = ss->inceval;
  int ksq = KSQ(Side), xksq = KSQ(XSide);
  int pawn_structure[2], e_pawn_structure[2];
  int passed_pawns[2] = {0, 0};
  int mobility[2] = {0, 0}, e_mobility[2] = {0, 0};
  int development[2];
  int passive_pieces[2] = {0, 0};
  int shield[2], ks_shield[2], qs_shield[2];
  int king_safety[2] = {0, 0};
  int king_activity[2] = {0, 0};
  int piece_placement[2] = {0, 0};
  int misc[2] = {0, 0};
  int e_misc[2] = {0, 0};
  int pawns[2], knights[2], bishops[2], rooks[2], queens[2];
  int np_material[2];
  int bishop_colour[2] = {0, 0};
  int rooks_on_7th[2] = {0, 0};
  int storm[2] = {0, 0};
  int space[2] = {0, 0};
  int scale[2] = {128, 128};
  int has_unstoppable[2] = {0, 0};
  int moves_to_go[2] = {9, 9};
  int side, x, d, sq, tosq;
  int *ptr;

  if(EngineOptions.use_eval_cache &&
     retrieve_eval(&result, ss->eval_vector.king_safety, 
                   ss->eval_vector.passed_pawns)) 
    return result;

  pawns[WHITE] = ss->pawns[WHITE]; pawns[BLACK] = ss->pawns[BLACK];
  np_material[WHITE] = ss->material[WHITE]-pawns[WHITE]*P_VALUE;
  np_material[BLACK] = ss->material[BLACK]-pawns[BLACK]*P_VALUE;

  /* Scale the score in some basic endgames: */
  if(ss->material[Side]+ss->material[XSide] <= Q_VALUE+R_VALUE+B_VALUE) {
    x = scale_endgame_eval(scale, ph);
    if(x) {
      result = (EndgameEvalFunction[x-1])();
      goto end_of_evaluate;
    }
  }
  else {
    if(pawns[WHITE] == 0 && ss->material[WHITE] <= 2*R_VALUE+B_VALUE &&
       np_material[WHITE] - np_material[BLACK] <= N_VALUE)
      scale[WHITE] = 48;
    if(pawns[BLACK] == 0 && ss->material[BLACK] <= 2*R_VALUE+B_VALUE &&
       np_material[BLACK] - np_material[WHITE] <= N_VALUE)
      scale[BLACK] = 48;
  }
  if(scale[WHITE] == 0 && scale[BLACK] == 0) {
    result = 0;
    goto end_of_evaluate;
  }

  /* Adjust piece square table score for king in the endgame: */
  e_result -= PSQ(FriendlyKing, ksq);
  e_result += KING_ENDGAME_PSQ(ksq);
  e_result += PSQ(EnemyKing, xksq);
  e_result -= KING_ENDGAME_PSQ(xksq);

  /* Pawn structure: */
  pawn_structure[WHITE] = ph->score[WHITE]; 
  pawn_structure[BLACK] = ph->score[BLACK];
  e_pawn_structure[WHITE] = ph->e_score[WHITE];
  e_pawn_structure[BLACK] = ph->e_score[BLACK];

  /* Initialise king shield and king activity: */
  for(side=WHITE; side<=BLACK; side++) {
    ksq=KSQ(side);
    shield[side] = evaluate_pawn_shield(side, ksq);
    ks_shield[side] = OO_POSSIBLE(side)?
      evaluate_pawn_shield(side, G1 + side*A8) : shield[side];
    qs_shield[side] = OOO_POSSIBLE(side)?
      evaluate_pawn_shield(side, C1 + side*A8) : shield[side];

    if(np_material[WHITE] + np_material[BLACK] < MIDGAME_MATERIAL) {
      for(sq = PL_START(WP); sq <= H8; sq = PL_NEXT(sq))
        king_activity[side] += KingActivityBonus[ksq - sq + 128];
      for(sq = PL_START(BP); sq <= H8; sq = PL_NEXT(sq))
        king_activity[side] += KingActivityBonus[sq - ksq + 128];
      king_activity[side] /= 2;
    }
  }

  for(side=WHITE; side<=BLACK; side++) {
    knights[side]=bishops[side]=rooks[side]=queens[side]=0;
    ksq=KSQ(side); xksq=KSQ(side^1);
    d=0;

    /* Evaluate knights: */
    for(sq=PL_START((side<<3)|KNIGHT); sq<=H8; sq=PL_NEXT(sq)) {
      knights[side]++;
      /* Penalize undeveloped knights: */
      if(PawnRank[side][sq]==RANK_1) d+=2;

      /* Don't block central pawns. */
      if((sq == (D3 ^ (side*0x70))) || (sq == (E3 ^ (side*0x70)))) {
        if(Board[sq-PawnPush[side]] == ((side<<3)|PAWN))
          misc[side] -= BLOCKING_CENTRAL_PAWN;
      }

      /* Compute mobility */
      x = 0;
      ptr = MobilityIncrement[side];
      x += ptr[Board[sq + 33]]; x += ptr[Board[sq + 31]]; 
      x += ptr[Board[sq + 18]]; x += ptr[Board[sq + 14]];
      x += ptr[Board[sq - 14]]; x += ptr[Board[sq - 18]];
      x += ptr[Board[sq - 31]]; x += ptr[Board[sq - 33]];
      x = max(x, 0);
      mobility[side] += NMobBonus[x]; e_mobility[side] += NMobBonus[x];
      if(x <= 2 && PSQ((side<<3)|KNIGHT, sq) < 10) passive_pieces[side]++;
    }

    /* Evaluate bishops: */
    for(sq=PL_START((side<<3)|BISHOP); sq<=H8; sq=PL_NEXT(sq)) {
      bishops[side]++;
      bishop_colour[side] |= SquareColour[sq];

      /* Compute mobility */
      x = 0;
      ptr = MobilityIncrement[side];
      for(tosq = sq + 15; Board[tosq] == EMPTY; tosq += 15) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 15; Board[tosq] == EMPTY; tosq -= 15) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq + 17; Board[tosq] == EMPTY; tosq += 17) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 17; Board[tosq] == EMPTY; tosq -= 17) x++;
      x += ptr[Board[tosq]];
      x = max(x, 0);
      mobility[side] += BMobBonus[x]; e_mobility[side] += BMobBonus[x];
      if(x <= 2) passive_pieces[side]++;

      if(PawnRank[side][sq]==RANK_1) {
        d++;
        if(x<=2) d++;
      }

      if((sq == (D3 ^ (side*0x70))) || (sq == (E3 ^ (side*0x70)))) {
        if(Board[sq-PawnPush[side]] == ((side<<3)|PAWN))
          misc[side] -= BLOCKING_CENTRAL_PAWN;
      }

      /* Trapped bishops on A7/H7/A2/H2: */
      if(side==WHITE) {
        if(sq==A7 && Board[B6]==BP && 
           (Board[C7]==BP || (swabbing(A7, B6)<0 && swabbing(A7, B8)<0)))
          piece_placement[WHITE] -= BISHOP_TRAPPED_A7H7;
        else if(sq==H7 && Board[G6]==BP && 
                (Board[F7]==BP || (swabbing(H7, G6)<0 && swabbing(H7, G8)<0)))
          piece_placement[WHITE] -= BISHOP_TRAPPED_A7H7;
      }
      else {
        if(sq==A2 && Board[B3]==WP && 
           (Board[C2]==WP || (swabbing(A2, B3)<0 && swabbing(A2, B1)<0)))
          piece_placement[BLACK] -= BISHOP_TRAPPED_A7H7;
        else if(sq==H2 && Board[G3]==WP && 
                (Board[F2]==WP || (swabbing(H2, G3)<0 && swabbing(H2, G1)<0)))
          piece_placement[BLACK] -= BISHOP_TRAPPED_A7H7;
      }

      /* An FRC pattern: A bishop on a1/h1/a8/h8 blocked by a pawn is bad. */
      if(EngineOptions.frc) {
        if(side==WHITE) {
          if(sq==A1 && Board[B2]==WP) {
            if(Board[B3] != EMPTY) 
              piece_placement[WHITE] -= 2*BISHOP_TRAPPED_A1H1;
            else if(Board[C3] == WP)
              piece_placement[WHITE] -= BISHOP_TRAPPED_A1H1;
            else
              piece_placement[WHITE] -= BISHOP_TRAPPED_A1H1/2;
          }
          else if(sq==H1 && Board[G2]==WP) {
            if(Board[G3] != EMPTY)
              piece_placement[WHITE] -= 2*BISHOP_TRAPPED_A1H1;
            else if(Board[F3] == WP)
              piece_placement[WHITE] -= BISHOP_TRAPPED_A1H1;
            else
              piece_placement[WHITE] -= BISHOP_TRAPPED_A1H1/2;
          }
        }
        else {
          if(sq==A8 && Board[B7]==BP) {
            if(Board[B6] != EMPTY)
              piece_placement[BLACK] -= 2*BISHOP_TRAPPED_A1H1;
            else if(Board[C6] == BP)
              piece_placement[BLACK] -= BISHOP_TRAPPED_A1H1;
            else
              piece_placement[BLACK] -= BISHOP_TRAPPED_A1H1/2;
          }
          else if(sq==H8 && Board[G7]==BP) {
            if(Board[G6] != EMPTY)
              piece_placement[BLACK] -= 2*BISHOP_TRAPPED_A1H1;
            else if(Board[F6] == BP)
              piece_placement[BLACK] -= BISHOP_TRAPPED_A1H1;
            else
              piece_placement[BLACK] -= BISHOP_TRAPPED_A1H1/2;
          }
        }
      }
    }

    /* Evaluate rooks: */
    for(sq=PL_START((side<<3)|ROOK); sq<=H8; sq=PL_NEXT(sq)) {
      rooks[side]++;

      /* Compute mobility */
      x = 0;
      ptr = MobilityIncrement[side];
      for(tosq = sq + 1; Board[tosq] == EMPTY; tosq++) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 1; Board[tosq] == EMPTY; tosq--) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq + 16; Board[tosq] == EMPTY; tosq += 16) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 16; Board[tosq] == EMPTY; tosq -= 16) x++;
      x += ptr[Board[tosq]];
      x = max(x, 0);
      mobility[side] += RMobBonus[x]; e_mobility[side] += RMobBonusEndgame[x];
      if(x <= 3 && !(ph->open_files[side] & FileMask[file(sq)]))
        passive_pieces[side]++;

      /* Rooks on 7th and 8th rank: */
      if(PawnRank[side][sq] >= RANK_7) rooks_on_7th[side] += 2;

      /* Bonus for open files: */
      if(ph->open_files[side] & FileMask[file(sq)]) {
        piece_placement[side] += ROOK_OPEN_FILE_BONUS;
      }
      else if(x <= 4) { /* Not open file, and poor mobility */
        /* Is the rook trapped inside a king which has lost the right to
         * castle? */
        if(EngineOptions.frc) {
          ksq = KSQ(side); 
          if(file(ksq) >= FILE_E && file(sq) > file(ksq) && 
             (PawnRank[side][ksq] == RANK_1 || rank(ksq) == rank(sq))) {
            for(tosq = file(ksq) + 1; tosq <= FILE_H; tosq++)
              if(ph->open_files[side] & FileMask[tosq]) break;
            if(tosq > FILE_H) {
              int step = PawnPush[side];
              for(tosq = sq + step; Board[tosq] != OUTSIDE; tosq += step)
                if(Board[tosq] == ((side<<3)|PAWN)) break;
              if(Board[tosq] != OUTSIDE) {
                d++;
                piece_placement[side] -= 
                  (OO_POSSIBLE(side) || OOO_POSSIBLE(side)) ?
                  (TRAPPED_ROOK - x * 16) / 2 : (TRAPPED_ROOK - x * 16);
              }
            }
          }
          if(file(ksq) <= FILE_D && file(sq) < file(ksq) && 
             (PawnRank[side][ksq] == RANK_1 || rank(ksq) == rank(sq))) {
            for(tosq = file(ksq) - 1; tosq >= FILE_A; tosq--)
              if(ph->open_files[side] & FileMask[tosq]) break;
            if(tosq < FILE_A) {
              int step = PawnPush[side];
              for(tosq = sq + step; Board[tosq] != OUTSIDE; tosq += step)
                if(Board[tosq] == ((side<<3)|PAWN)) break;
              if(Board[tosq] != OUTSIDE) {
                d++;
                piece_placement[side] -= 
                  (OO_POSSIBLE(side) || OOO_POSSIBLE(side)) ?
                  (TRAPPED_ROOK - x * 16) / 2 : (TRAPPED_ROOK - x * 16);
              }
            }
          }
        }
        else { /* Normal chess */
          if(sq==H1+side*A8) {
            if(ksq==sq-1 || ksq==sq-2) piece_placement[side] -= TRAPPED_ROOK;
          }
          else if(sq==G1+side*A8) {
            if(ksq==sq-1) piece_placement[side] -= TRAPPED_ROOK;
          }
          else if(sq==A1+side*A8) {
            if(ksq==sq+1 || ksq==sq+2) piece_placement[side] -= TRAPPED_ROOK;
          }
          else if(sq==B1+side*A8) {
            if(ksq==sq+1) piece_placement[side] -= TRAPPED_ROOK;
          }
        }
      }
    }

    /* Evaluate queens: */
    for(sq=PL_START((side<<3)|QUEEN); sq<=H8; sq=PL_NEXT(sq)) {
      queens[side]++;

      /* Queens on 7th and 8th rank: */
      if(PawnRank[side][sq] >= RANK_7) rooks_on_7th[side]++;

      /* Compute mobility */
      x = 0;
      ptr = MobilityIncrement[side];
      for(tosq = sq + 15; Board[tosq] == EMPTY; tosq += 15) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 15; Board[tosq] == EMPTY; tosq -= 15) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq + 17; Board[tosq] == EMPTY; tosq += 17) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 17; Board[tosq] == EMPTY; tosq -= 17) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq + 1; Board[tosq] == EMPTY; tosq++) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 1; Board[tosq] == EMPTY; tosq--) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq + 16; Board[tosq] == EMPTY; tosq += 16) x++;
      x += ptr[Board[tosq]];
      for(tosq = sq - 16; Board[tosq] == EMPTY; tosq -= 16) x++;
      x += ptr[Board[tosq]];
      x = max(x, 0);
      mobility[side] += QMobBonus[x]; e_mobility[side] += QMobBonusEndgame[x];
    }

    /* Development eval: */
    development[side] = DevelopmentPenalty[d];

    /* Penalize early queen activity: */
    if(d>=4 && queens[side] && Board[D1+side*A8] != ((side<<3)|QUEEN))
      misc[side] -= EARLY_QUEEN_ACTIVITY;
  }

  for(side = WHITE; side <= BLACK; side++) {
    /* Bonus for queens/rooks on 7th rank: */
    misc[side] += RooksOn7thBonus[rooks_on_7th[side]];
    if(PawnRank[side^1][KSQ(side^1)] == RANK_1)
      e_misc[side] += RooksOn7thBonus[rooks_on_7th[side]];

    /* FRC: Penalty for multiple passive pieces.  Perhaps useful for normal
     * chess as well. */
    misc[side] -= MultiplePassivePenalty[passive_pieces[side]];

    /* Bishop pair: */
    if(bishop_colour[side] == 3) {
      misc[side] += BishopPairBonus[ph->centre];
      e_misc[side] += BishopPairBonus[ph->centre];
      if(!bishops[side^1] && !knights[side^1]) {
        misc[side] += 30; e_misc[side] += 30;
      }
    }

    /* Adjust knight and rook material values by number of pawns, using
     * Larry Kaufmann's formulas: */
    misc[side] += rooks[side]*(5-pawns[side])*32;
    e_misc[side] += rooks[side]*(5-pawns[side])*32;
    misc[side] += knights[side]*(pawns[side]-6)*16;
    e_misc[side] += knights[side]*(pawns[side]-6)*16;

    /* Redundancy of major pieces, again based on Kaufmann's paper: */
    if(rooks[side]) {
      misc[side] -= (rooks[side]-1)*32 + queens[side]*16;
      e_misc[side] -= (rooks[side]-1)*32 + queens[side]*16;
    }

    if(np_material[WHITE]+np_material[BLACK] > ENDGAME_MATERIAL) {
      /* King safety: */
      king_safety[side] = evaluate_king_safety(side, shield[side], 
                                               ph->open_files[side^1]);

      /* Pawn storms at positions with opposite castling: */
      if(file(KSQ(side)) >= FILE_F && file(KSQ(side^1)) <= FILE_D)
        storm[side] = ph->q_storm[side];
      else if(file(KSQ(side)) <= FILE_D && file(KSQ(side^1)) >= FILE_F)
        storm[side] = ph->k_storm[side];

      /* Space */
      space[side] = 
        (ph->space[side] * (np_material[side]-Q_VALUE-R_VALUE-B_VALUE)) / 256;
      if(space[side] < 0) space[side] = 0;
    }

    /* Outposts: */
    for(x = 0; x < 8 && ph->outpost_squares[side][x] != 0; x++) {
      int sq = ph->outpost_squares[side][x], sq2, step = PawnPush[side];
      int knight = (side<<3)|KNIGHT, bishop = (side<<3)|BISHOP, 
        rook = (side<<3)|ROOK;
      int bonus;

      if(Board[sq] == knight || Board[sq] == bishop) {
        bonus = OutpostBonus[side][sq];
        if(Board[sq] == knight) bonus *= 2;
        /* Increase bonus if supported by rook. */
        for(sq2 = sq - step; Board[sq2] == EMPTY; sq2 -= step);
        if(Board[sq2] == rook) bonus += bonus/4;
        /* Increase bonus if opponent cannot challenge the outpost. */
        if(knights[side^1]==0 && !(bishop_colour[side^1]&SquareColour[sq])) 
          bonus *= (bishops[side^1]? 3 : 2);
        piece_placement[side] += bonus;
      }
    }

    /* Passed pawns: */
    for(x = 0; x < 8 && ph->passed_pawn_squares[side][x] != 0; x++) {
      int sq = ph->passed_pawn_squares[side][x];
      int rank = PawnRank[side][sq];
      int step = PawnPush[side];
      int bonus = PpBonus[rank];
      int pawn = (side<<3)|PAWN;
      int xknight = ((side^1)<<3)|KNIGHT, xbishop = ((side^1)<<3)|BISHOP;
      int xking = ((side^1)<<3)|KING;
      int rook = (side<<3)|ROOK, xrook = ((side^1)<<3)|ROOK;

      if(COLOUR(Board[sq+step]) == (side^1)) bonus /= 2;
      else if(rank >= RANK_6 && Board[sq+step] == EMPTY && 
              queens[side^1] == 0 && swabbing(sq, sq+step) == 0) {
        /* Pawn can safely advance, increase bonus: */
        if(rank == RANK_7) bonus += (side == Side)? 200 : 100;
        else bonus += (side == Side)? 40 : 16;
      }

      /* Is there a friendly pawn beside or diagonally behind? */
      if(Board[sq-1] == pawn || Board[sq+1] == pawn) bonus += PpBonus[rank];
      else for(d = sq - step - 1; d <= sq - step + 1; d += 2) {
        if(Board[d] == pawn) {
          /* This is a protected pawn, and the bonus should be increased.
           * We increase by a smaller amount if an enemy king, bishop or
           * knight hinders the advance of the pawn duo. */
          if(Board[sq+step] == xking || Board[sq+step] == xbishop ||
             Board[sq+step] == xknight || 
             Board[d+step] == xking || Board[d+step] == xbishop ||
             Board[d+step] == xknight)
            bonus += PpBonus[rank]/2;
          else
            bonus += PpBonus[rank];
        }
      }

      /* Is the enemy king somewhere in the pawn's path? */
      d = file(KSQ(side^1)) - file(sq);
      if(abs(d) <= 1 && (rank(KSQ(side^1)) - rank(sq)) * step >= 0)
        bonus -= PpBonus[rank] / 4;

      /* Is there a friendly or enemy rook behind the pawn? */
      for(tosq = sq - step; Board[tosq] == EMPTY; tosq -= step);
      if(Board[tosq] == rook) bonus += PpBonus[rank] / 4;
      else if(Board[tosq] == xrook) bonus -= PpBonus[rank] / 4;

      /* A passed rook pawn is very strong against a knight. */
      if(!queens[side^1] && !rooks[side^1] && !bishops[side^1] &&
         knights[side^1] == 1)
        bonus += bonus/2;

      passed_pawns[side] += bonus;

      /* If the other side has only a king, check whether the pawn is
       * unstoppable: */
      if(np_material[side^1] == 0) {
        int qsq, tempo, mtg;
        if((side^1) == Side) tempo = 1; else tempo = 0;
        qsq = file(sq) + (side^1)*A8;
        d = DISTANCE(sq, qsq) - DISTANCE(KSQ(side^1), qsq) + tempo;
        if(d < 0) {
          mtg = RANK_8-PawnRank[side][sq];
          for(tosq = sq + step; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] != EMPTY) {mtg++; d++;}
          if(d < 0) {
            has_unstoppable[side]++;
            moves_to_go[side] = min(moves_to_go[side], mtg);
          }
        }
      }

      /* Give king activity bonus for king close to the passed pawn: */
      if(side == WHITE) {
        king_activity[WHITE] += KingActivityBonus[KSQ(WHITE)-sq+128] * 2;
        king_activity[BLACK] += KingActivityBonus[KSQ(BLACK)-sq+128] * 2;
      }
      else {
        king_activity[WHITE] += KingActivityBonus[sq-KSQ(WHITE)+128] * 2;
        king_activity[BLACK] += KingActivityBonus[sq-KSQ(BLACK)+128] * 2;
      }
    }
  }
  if(has_unstoppable[WHITE] && !has_unstoppable[BLACK])
    passed_pawns[WHITE] += R_VALUE - 64*moves_to_go[WHITE];
  else if(has_unstoppable[BLACK] && !has_unstoppable[WHITE])
    passed_pawns[BLACK] += R_VALUE - 64*moves_to_go[BLACK];

  for(side = WHITE; side <= BLACK; side++) {
    ss->eval_vector.king_safety[side] = king_safety[side];
    ss->eval_vector.passed_pawns[side] = passed_pawns[side];
  }
 
  result += ((pawn_structure[Side] - pawn_structure[XSide])
             * EngineOptions.ps_weight) / 128;
  e_result += ((pawn_structure[Side] - pawn_structure[XSide])
             * EngineOptions.ps_weight) / 128;

  result += ((mobility[Side] - mobility[XSide])
             * EngineOptions.mob_weight) / 128;
  e_result += ((e_mobility[Side] - e_mobility[XSide])
               * EngineOptions.e_mob_weight) / 128;

  result += ((space[Side] - space[XSide]) * EngineOptions.space_weight) / 128;

  result += piece_placement[Side] - piece_placement[XSide];
  e_result += piece_placement[Side] - piece_placement[XSide];

  result += ((passed_pawns[Side] - passed_pawns[XSide]) 
             * EngineOptions.pp_weight) / 256;
  e_result += ((passed_pawns[Side] - passed_pawns[XSide])
               * EngineOptions.pp_weight) / 128;

  king_activity[WHITE] -= king_activity[WHITE]/4;
  king_activity[BLACK] -= king_activity[BLACK]/4;
  e_result += king_activity[Side] - king_activity[XSide];

  result += misc[Side] - misc[XSide];
  e_result += e_misc[Side] - e_misc[XSide];
  result += ((development[Side] - development[XSide])
             * EngineOptions.development_weight) / 128;
  
  shield[Side] = (shield[Side] + max(ks_shield[Side], qs_shield[Side])) / 2;
  shield[XSide] = (shield[XSide] + max(ks_shield[XSide], qs_shield[XSide])) / 2;
  result += (shield[Side] - shield[XSide]) * 8;
  
  result += 
    ((king_safety[Side] * EngineOptions.ks_weight[Side]) -
     (king_safety[XSide] * EngineOptions.ks_weight[XSide])) / 128;

  result += storm[Side] - storm[XSide];

  /* Reduce endgame score in the case of opposite-coloured bishops: */
  if(bishops[WHITE]==1 && bishops[BLACK]==1 && 
     bishop_colour[WHITE] != bishop_colour[BLACK] &&
     scale[WHITE] == 128 && scale[BLACK] == 128) {
    if(np_material[WHITE]+np_material[BLACK]==2*B_VALUE) {
      scale[WHITE] = scale[BLACK] = 64;
    }
    else {
      scale[WHITE] = scale[BLACK] = 96;
    }
  }

  result += TEMPO_BONUS_MIDGAME; e_result += TEMPO_BONUS_ENDGAME;

  if(e_result > 0) e_result = (e_result*scale[Side]) / 128;
  else e_result = (e_result*scale[XSide]) / 128;

  if(np_material[WHITE]+np_material[BLACK] >= MIDGAME_MATERIAL) 
    result = (result & ~(GRAIN_SIZE-1));
  else if(np_material[WHITE]+np_material[BLACK] <= ENDGAME_MATERIAL) 
    result = (e_result & ~(GRAIN_SIZE-1));
  else result = 
    ((((np_material[WHITE]+np_material[BLACK]-ENDGAME_MATERIAL) * result) /
      (MIDGAME_MATERIAL-ENDGAME_MATERIAL) +
      ((MIDGAME_MATERIAL-np_material[WHITE]-np_material[BLACK]) * e_result) /
      (MIDGAME_MATERIAL-ENDGAME_MATERIAL)) & ~(GRAIN_SIZE-1));

 end_of_evaluate:
  if(EngineOptions.use_eval_cache)
    store_eval(result, ss->eval_vector.king_safety, 
               ss->eval_vector.passed_pawns);
  return result;
}

int approx_eval_after_move(move_t m) {
  int c = (CAPTURE(m)|(XSide<<3)), p = (PIECE(m)|(Side<<3)), pr = PROMOTION(m);

  if(pr) {
    pr |= (Side<<3);
    return SearchStack[Ply].eval 
      + (PieceValues[c] + PieceValues[pr] - PieceValues[PAWN] - PSQ(p, FROM(m))
         + PSQ(pr, TO(m)) + PSQ(c, TO(m)));
  }
  return SearchStack[Ply].eval 
    + (PieceValues[c] - PSQ(p, FROM(m)) + PSQ(p, TO(m)) + PSQ(c, TO(m)));
}

int draw(void) {
  int i;
  if(Pos.rule50 > 100) return 1;
  if(Pos.rule50 == 100 && !in_check(Side)) return 1;
  if(SearchStack[Ply].material[WHITE]==0 &&
     SearchStack[Ply].material[BLACK]==0)
    return 1;
  if(SearchStack[Ply].pawns[WHITE]==0 && SearchStack[Ply].pawns[BLACK]==0 &&
     SearchStack[Ply].material[WHITE]+SearchStack[Ply].material[BLACK]<R_VALUE)
    return 1;
  for(i=2; i<min(GPly, Pos.rule50); i+=2)
    if(Pos.previous_keys[GPly-i]==Pos.key) return 1;
  return 0;
}


