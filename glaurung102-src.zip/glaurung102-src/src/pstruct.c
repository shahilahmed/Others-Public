#include "glaurung.h"

#define P_HASH_SIZE 65536

/* Isolated, double and backward pawn penalties by file: */
int IpPenalty[8] = {4, 8, 14, 20, 20, 14, 8, 4};
int DpPenalty[8] = {4, 8, 14, 20, 20, 14, 8, 4};
int BpPenalty[8] = {4, 8, 14, 20, 20, 14, 8, 4};

/* Bonus for being member of a pawn chain: */
int ChainBonus = 10;

/* Penalty for multiple pawn structure defects: */
int MdpPenalty[9] = {0, 0, 3, 10, 25, 50, 60, 60, 60};

/* Pawn storm tables for positions with opposite castling: */
int8 QStormTable[128] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  -15, -15, -15, -9, -3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  -3, -6, -6, -6, -3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  6, 12, 15, 12, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  15, 21, 21, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  21, 27, 27, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  21, 27, 27, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

int8 KStormTable[128] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, -3, -9, -15, -18, -18, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, -3, -6, -9, -12, -12, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 6, 12, 18, 18, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 6, 18, 27, 24, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 21, 27, 21, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

uint8 SpaceBonus[128] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 2, 4, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 2, 4, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/* Candidate passed pawn bonus by rank: */
int CandidateBonus[8] = {0, 10, 10, 20, 33, 53, 0, 0};

p_hashentry_t *PawnHashTable; 

void init_pawn_hash_table(void) {
  free_pawn_hash_table();
  PawnHashTable = malloc(P_HASH_SIZE * sizeof(p_hashentry_t));
  memset(PawnHashTable, 0, P_HASH_SIZE * sizeof(p_hashentry_t));
}

void free_pawn_hash_table(void) {
  free(PawnHashTable);
}

p_hashentry_t *analyse_pawn_structure(void) {
  p_hashentry_t *ph = PawnHashTable+(Pos.pkey&(P_HASH_SIZE-1));
  int side, sq;

  if(ph->key == Pos.pkey) return ph;

  ph->key = Pos.pkey;
  ph->score[WHITE] = ph->score[BLACK] = 0; 
  ph->e_score[WHITE] = ph->e_score[BLACK] = 0;
  ph->open_files[WHITE] = ph->open_files[BLACK] = 0xFF;
  ph->k_storm[WHITE] = ph->k_storm[BLACK] = 0;
  ph->q_storm[WHITE] = ph->q_storm[BLACK] = 0;
  ph->space[WHITE] = ph->space[BLACK] = 0;

  for(side=WHITE; side<=BLACK; side++) {
    int enemy_pawn = ((side^1)<<3)|PAWN, friendly_pawn = (side<<3)|PAWN;
    int num_of_passed_pawns = 0, num_of_outposts = 0, num_of_defects = 0;
    for(sq=PL_START(friendly_pawn); sq<=H8; sq=PL_NEXT(sq)) {
      int passed, candidate, chain, doubled, isolated, backward;
      int step = PawnPush[side], tosq;
      int file = file(sq), rank;
      int *ptr;
      int bonus;

      /* The file occupied by this pawn is not open: */
      ph->open_files[side] &= ~FileMask[file];

      /* Pawn stroms: */
      bonus = KStormTable[sq^(side*0x70)];
      if(bonus) {
        switch(file) {
        case FILE_H: 
          for(tosq = sq + step - 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/2;
              else
                bonus *= 2;
              break;
            }
          break;
        case FILE_G:
          for(tosq = sq + step + 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/2 + bonus/4;
              else
                bonus += bonus + bonus/2;
              break;
            }
          break;
        case FILE_F:
          for(tosq = sq + step + 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/4;
              else
                bonus += bonus/2;
              break;
            }
          break;
        }
        ph->k_storm[side] += bonus;
      }

      bonus = QStormTable[sq^(side*0x70)];
      if(bonus) {
        switch(file) {
        case FILE_A: 
          for(tosq = sq + step + 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/2;
              else
                bonus *= 2;
              break;
            }
          break;
        case FILE_B:
          for(tosq = sq + step - 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/2 + bonus/4;
              else
                bonus += bonus + bonus/2;
              break;
            }
          break;
        case FILE_C:
          for(tosq = sq + step - 1; Board[tosq] != OUTSIDE; tosq += step)
            if(Board[tosq] == enemy_pawn) {
              if(Board[tosq-1] == enemy_pawn || Board[tosq+1] == enemy_pawn)
                bonus += bonus/4;
              else
                bonus += bonus/2;
              break;
            }
          break;
        }
        ph->q_storm[side] += bonus;
      }

      /* Space: */
      bonus = SpaceBonus[sq^(side*0x70)];
      if(bonus) {
        ph->space[side] += bonus;
        if(Board[sq-1] == friendly_pawn || Board[sq+1] == friendly_pawn)
          ph->space[side] += bonus;
        else if(Board[sq-step-1]==friendly_pawn ||
                Board[sq-step+1]==friendly_pawn)
          ph->space[side] += bonus/2;
      }

      /* Passed pawn? */
      passed = 1;
      for(tosq = sq + step; Board[tosq] != OUTSIDE; tosq += step) {
        if(Board[tosq-1]==enemy_pawn||Board[tosq]==enemy_pawn
           ||Board[tosq+1]==enemy_pawn) { /* not passed. */
          passed = 0; break;
        }
      }

      /* Candidate passed pawn? */
      if(passed) candidate = 0;
      else {
        int x = 0;
        candidate = 1;
        for(tosq = sq + step; Board[tosq] != OUTSIDE; tosq += step) {
          if(PIECE_TYPE(Board[tosq]) == PAWN) {
            candidate = 0; break;
          }
          if(Board[tosq-1] == enemy_pawn) x++;
          if(Board[tosq+1] == enemy_pawn) x++;
        }
        if(x >= 2) candidate = 0;
        if(candidate) {
          candidate = 0;
          for(tosq = sq; Board[tosq] != OUTSIDE; tosq -= step) {
            if(Board[tosq-1]==friendly_pawn || Board[tosq+1]==friendly_pawn) {
              candidate = 1; break;
            }
          }
        }
      }

      /* Doubled pawn?  Only the frontmost double pawn counts! */
      doubled = 0;
      for(tosq=sq-step; Board[tosq]!=OUTSIDE; tosq-=step) {
        if(Board[tosq]==friendly_pawn) {
          doubled = 1; break;
        }
      }

      /* Isolated pawn? */
      isolated = 1;
      for(rank=RANK_2; rank<=RANK_7; rank++) {
        if(Board[rank*16+file-1]==friendly_pawn || 
           Board[rank*16+file+1]==friendly_pawn) {
          isolated = 0; break;
        }
      }

      /* Backward pawn? */
      backward = 0;
      if(!isolated && !passed) {
        backward = 1;
        for(tosq=sq; Board[tosq]!=OUTSIDE; tosq-=step) {
          if(Board[tosq-1]==friendly_pawn || Board[tosq+1]==friendly_pawn) {
            backward=0; break;
          }
        }
        if(Board[sq+step-1] == enemy_pawn || Board[sq+step-1] == enemy_pawn)
          backward = 0;
        if(backward) {
          for(tosq=sq+step; Board[tosq]!=OUTSIDE; tosq+=step) {
            if(Board[tosq+step-1]==enemy_pawn||Board[tosq+step+1]==enemy_pawn) 
              break;
            if(Board[tosq-1]==friendly_pawn || Board[tosq+1]==friendly_pawn) {
              backward=0; break;
            }
          }
        }
      }

      if(passed) 
        ph->passed_pawn_squares[side][num_of_passed_pawns++] = sq;

      /* Outpost square in front of pawn? */
      if((isolated||backward) && file(sq-step)>=FILE_C && file(sq+step)<=FILE_F
         && rank(sq+step) >= RANK_3 && rank(sq+step) <= RANK_6
         && PIECE_TYPE(Board[sq+step]) != PAWN
         && (Board[sq+2*step-1]==enemy_pawn||Board[sq+2*step+1]==enemy_pawn)) {
        for(tosq=sq+2*step; Board[tosq]!=OUTSIDE && Board[tosq]!=enemy_pawn;
            tosq+=step);
        if(Board[tosq] == OUTSIDE)
          ph->outpost_squares[side^1][num_of_outposts++] = sq+step;
      }

      /* Member of a pawn chain or phalanx? */
      chain = 0;
      if(Board[sq+1]==friendly_pawn || Board[sq+2]==friendly_pawn)
        chain = 1;
      else for(ptr=Directions[friendly_pawn]; *ptr; ptr++) 
        if(Board[sq-(*ptr)]==friendly_pawn) chain = 1;
      
      /* Compute score for this pawn: */
      file = file(sq), rank = PawnRank[side][sq];

      if(doubled) {
        ph->score[side] -= DpPenalty[file]; 
        ph->e_score[side] -= DpPenalty[file];
        num_of_defects++;
      }
      if(isolated) {
        ph->score[side] -= IpPenalty[file]; 
        ph->e_score[side] -= IpPenalty[file];
        num_of_defects++;
      }
      if(backward) {
        ph->score[side] -= BpPenalty[file];
        ph->e_score[side] -= BpPenalty[file];
        num_of_defects++;
      }
      if(chain) {
        ph->score[side] += ChainBonus; 
        ph->e_score[side] += ChainBonus;
      }
      if(candidate) {
        ph->score[side] += CandidateBonus[rank] / 2;
        ph->e_score[side] += CandidateBonus[rank];
      }
    }
    if(num_of_passed_pawns < 8)
      ph->passed_pawn_squares[side][num_of_passed_pawns] = 0;
    if(num_of_outposts < 8)
      ph->outpost_squares[side^1][num_of_outposts] = 0;

    /* Include open file information in pawn storm eval: */
    if(ph->open_files[side] & FileMask[FILE_H])
      ph->k_storm[side] += 30;
    if(ph->open_files[side] & FileMask[FILE_G])
      ph->k_storm[side] += 30;
    if(ph->open_files[side] & FileMask[FILE_F])
      ph->k_storm[side] += 20;
    if(ph->open_files[side] & FileMask[FILE_A])
      ph->q_storm[side] += 20;
    if(ph->open_files[side] & FileMask[FILE_B])
      ph->q_storm[side] += 30;
    if(ph->open_files[side] & FileMask[FILE_C])
      ph->q_storm[side] += 20;

    /* Add progressive penalty for multiple pawn structure defects: */
    ph->score[side] -= MdpPenalty[num_of_defects];
    ph->e_score[side] -= MdpPenalty[num_of_defects];
  }
  if(ph->space[WHITE] > 24) ph->space[WHITE] = 24;
  if(ph->space[BLACK] > 24) ph->space[BLACK] = 24;

  /* Analyse the central pawn structure.  The following types of central
   * structures are defined:
   *
   *     OPEN:         At most one pawn on the e and d files.
   *     HALF-OPEN:    Two or three pawns on the e and d files, and no pawn
   *                   is blocked.
   *     HALF-CLOSED:  Two, three or four pawns on the e and d files, and 
   *                   there is a pawn ram.
   *     TENSION:      A central pawn capture is possible.
   *     UNRESLOVED:   Four central pawns, still not in direct contact.
   *     CLOSED:       Four central pawns, none of which can move.
   */
  {
    int central_pawns[2] = {0,0};
    for(side = WHITE; side <= BLACK; side++) {
      if(~ph->open_files[side] & FileMask[FILE_D]) central_pawns[side]++;
      if(~ph->open_files[side] & FileMask[FILE_E]) central_pawns[side]++;
    }
    if(central_pawns[WHITE] + central_pawns[BLACK] <= 1) ph->centre = OPEN;
    else {
      ph->centre = UNKNOWN;
      /* Is a central pawn capture available? */
      for(sq = D2; sq <= D6; sq += 16) {
        if(Board[sq] == WP && Board[sq+17] == BP) {
          ph->centre = TENSION; break;
        }
      }
      if(ph->centre == UNKNOWN) {
        for(sq = E2; sq <= E6; sq += 16) {
          if(Board[sq] == WP && Board[sq+15] == BP) {
            ph->centre = TENSION; break;
          }
        }
      }
      if(ph->centre == UNKNOWN) {
        if(central_pawns[WHITE] + central_pawns[BLACK] <= 3) {
          /* Is there a pawn ram? */
          for(sq = D2; sq <= D7; sq += 16) {
            if(Board[sq] == WP && Board[sq+16] == BP) {
              ph->centre = HALF_CLOSED; break;
            }
          }
          if(ph->centre == UNKNOWN) {
            for(sq = E2; sq <= E7; sq += 16) {
              if(Board[sq] == WP && Board[sq+16] == BP) {
                ph->centre = HALF_CLOSED; break;
              }
            }
          }
          if(ph->centre == UNKNOWN) ph->centre = HALF_OPEN;
        }
        else { /* Four central pawns */
          ph->centre = UNRESOLVED;
          for(sq = D2; sq <= D6; sq += 16) {
            if(Board[sq] == WP && Board[sq+16] == BP) ph->centre = HALF_CLOSED;
          }
          for(sq = E2; sq <= E6; sq += 16) {
            if(Board[sq] == WP && Board[sq+16] == BP) {
              if(ph->centre == UNRESOLVED) ph->centre = HALF_CLOSED;
              else ph->centre = CLOSED;
            }
          }
        }
      }
    }
  }

  return ph;
}
