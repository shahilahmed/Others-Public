1. Introduction
---------------

Glaurung is a simple and minimalistic UCI chess engine.  Compared to
other chess programs, it is neither very fast nor particularly
intelligent, but on fast modern computers it is nevertheless strong
enough to give most human players a good challenge.  The source code
is delivered under the GNU Public License; see the file Copying.txt
for details.  The program should compile easily in Windows and most
Unix variants (including Mac OS X).

I started working on Glaurung in the autumn of 2004, when my old chess
engine (Gothmog) got so complex and buggy that there was no point in
trying to improve it further.  My goal with the new engine was to
construct a very simple program with compact code and data
requirements, and to make the code general enough to handle hexagonal
chess with just a small number of changes.  Scatha, Glaurung's
hexagonal twin brother, is available as a separate download.


2. Using the program
--------------------

In order to use Glaurung, you need a chess GUI with support for the
UCI or xboard protocol.  Installing Glaurung in a UCI compatible GUI
(like Arena, Shredder, Fritz, Jos� or Sigma Chess) should be
straightforward.  Using it with an xboard compatible GUI (like xboard,
Winboard or ChessMaster 10000) is slightly more tricky, you will have
to install and use Fabien Letouzey's excellent PolyGlot utility.
PolyGlot is available from the download section of the WBEC site
(http://wbec-ridderkerk.nl).  Please use the polyglot.ini file
supplied with Glaurung.


3. UCI options
--------------

The most important components of Glaurung's evaluation function can be
configured through the UCI interface (edit the polyglot.ini file if
you use Glaurung in xboard or Winboard).  You can try to modify the
settings if you want to change the program's style of play.  It is not
at all clear that the default settings are optimal.  If you discover
some settings which seem to be clearly stronger than the defaults,
please let me know.

The configurable options in Glaurung 1.0 are:

* "Aggressiveness" (between 0 and 200, the default is 150).  This is
  the weight given to the king safety evaluation of the opponent.  Big
  values will make Glaurung more willing to sacrifice material or make
  positional concessions in order to attack the enemy king. 

* "Cowardice" (between 0 and 200, the default is 100).  This is the
  weight given to Glaurung's own king safety.  With high values,
  Glaurung will be very cautious about its own king.  Low values will
  result in more reckless play.

* "Passed pawns" (between 0 and 200, the default is 140).  The weight
  given to the passed pawn evaluation.  High values will make Glaurung
  assign big bonuses to passed pawns.

* "Pawn structure" (between 0 and 200, the default is 150).  The
  weight of the pawn structure evaluation.  With high values, Glaurung
  will try harder to avoid pawn structure defects like isolated,
  double and backward pawns.

* "Mobility (middle game)" and "Mobility (endgame)" (between 0 and
  200, the defaults are 130 and 110).  Mobility is a measure of the
  number of possible moves for each piece on the board.

* "Space" (between 0 and 200, the default is 100) is the weight of the
  evaluation of space and central control.  The default value of 100 is
  rather high and speculative, it is possible that a slightly lower 
  value would perform better in normal chess.  In FRC (also known as
  Chess960), however, values even higher than 100 seem to work well.

* "Development" (between 0 and 200, the default is 130) controls the
  evaluation of development.  With high values, Glaurung will make a
  bigger effort to activate its pieces quickly in the opening.

* "Static evaluation cache" (on or off, default is on).  The static
  evaluation cache is used to store data about the positions Glaurung
  has already evaluated.  Enabling the static evaluation cache makes
  Glaurung a tiny bit faster at some computers (at the expense of some
  memory use).  This seems to depend on the computer used.  You will
  have to try to find out whether the static evaluation cache improves
  performance on your machine.  At any rate, the difference is not
  big.

* "Static evaluation cache size" (between 1 and 64, the default is
  4).  The size of the evaluation cache, measured in megabytes.  If
  the static evaluation cache seems to help on your computer, you may
  be able to improve the performance even further by increasing the
  cache size.  

* "Static null move pruning" (on or off, the default is on).  When
  this is enabled, Glaurung will use its evaluation function to prune
  some branches of the game tree near the leaves.  This reduces the
  number of positions Glaurung needs to examine to reach a given
  depth, but with a risk of introducing tactical errors.  I think
  Glaurung is tactically stronger with static null move pruning
  disabled, but the positional benefits are probably enough to
  compensate.  

* "Static pruning depth" (between 1 and 4, the default is 2).
  Controls how close to the leaves static null move pruning is
  allowed.  Values above 2 are probably too risky, but I haven't made
  enough tests to be sure.


4. Opening book
---------------

An opening book for Glaurung is available as a separate download.
This book is quite bad, and not tuned for Glaurung's style of play.
If your favorite GUI includes an opening book, using the GUI book
rather than Glaurung's own book is recommended.

Please note that Glaurung 1.0 and later uses a new book format.  The
opening book from Glaurung Mainz and older versions will not work in
Glaurung 1.0.


5. Acknowledgments
------------------

Thanks to the big, friendly and helpful amateur computer chess
community, chess programming is no longer a very difficult endeavour
(unless you want to become a world champion).  The list of friendly
programmers who have helped me learn the craft of chess programming is
long.  I have learned a lot from Dieter Buerssner, Anthony Cozzie,
Vincent Diepeveen, Dusan Dobes, Sune Fischer, Bob Hyatt, Sergei
Markoff, Richard Pijl, Ed Schroder, Chris Whittington, and many other
programmers at the Computer Chess Club and the Winboard Forum.  A
special thanks to the following three people:

* Peter Fendrich, who first introduced me to chess programming.

* Grzegorz Szidorowicz, for encouraging me to write a hexagonal chess
  program, and for his advice during the development process.

* Fabien Letouzey, for generously sharing thoughts, ideas and code,
  for creating Fruit and PolyGlot, and most of all for being the best
  of my many friends in the computer chess community.

No less important than the programmers are the many enthusiasts who
run matches and tournaments between amateur chess engines.  Without
their help, chess programming would not be nearly as fun to do.  A big
thanks to Robert Allgeuer, Christian Bartsch, Roger Brown, Patrick
Buchmann, Dann Corbit, Olivier Deville, Leo Dijksman, Wolfgang
Draeger, Peter Eizenhammer, Igor Gorelikov, Lars Hallerstr�m, Heinz
van Kempen, Uschi van Kempen, Christian Koch, Gabriel Leperlier,
G�nther Simon, Kurt Utzinger, Ciro Vignotto, and all the other testers
out there.

Thanks to Jim Ablett, Dann Corbit and Bryan Hofmann for compiling
optimised Windows binaries of my program.


6. Feedback
-----------

If you have questions, comments or wishes for new features in future
versions of Glaurung, feel free to contact me.  My e-mail address is
tord@glaurungchess.com.

