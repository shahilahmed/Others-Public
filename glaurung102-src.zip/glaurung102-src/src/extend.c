#include "glaurung.h"

#define CHECK_EXT 60
#define SINGLE_REPLY_EXT 45
#define TWO_REPLIES_EXT 20
#define MATE_THREAT_EXT 45
#define KING_SAFETY_EXT 30
#define PAWN_PUSH_7TH_EXT 45
#define PAWN_PUSH_6TH_EXT 30
#define PAWN_ENDGAME_EXT_1 150
#define PAWN_ENDGAME_EXT_2 90
#define PAWN_ENDGAME_EXT_3 60

int extend(move_t m, int *ext, int *reason, int mate_threat, int ks_delta) {
  search_stack_t *ss = SearchStack+Ply;
  *ext = 0; *reason = 0;

  FIND_CHECKERS();
  if(ss->check) {
    *ext += CHECK_EXT;
    *reason |= CHECK_EXT_MASK;
  }
  if((ss-1)->check && (ss-1)->num_of_evasions==1) {
    *ext += SINGLE_REPLY_EXT;
    *reason |= SINGLE_REPLY_EXT_MASK;
  }
  if((ss-1)->check && (ss-1)->num_of_evasions==2) {
    *ext += TWO_REPLIES_EXT;
  }
  if(mate_threat) {
    *ext += MATE_THREAT_EXT;
    *reason |= MATE_THREAT_EXT_MASK;
  }
  if(!(ss-1)->check && ks_delta < -256 && 
     !((ss-1)->last_moved_piece_hanging)) {
    *ext += KING_SAFETY_EXT;
  }
  if(PIECE(m)==PAWN && PawnRank[XSide][TO(m)] == RANK_7) {
    *ext += PAWN_PUSH_7TH_EXT;
  }
  if(PIECE(m)==PAWN && PawnRank[XSide][TO(m)] == RANK_6) {
    *ext += PAWN_PUSH_6TH_EXT;
  }
  if(CAPTURE(m) > PAWN && pawn_endgame()) {
    switch(CAPTURE(m)) {
    case QUEEN: *ext = PAWN_ENDGAME_EXT_1; return *ext;
    case ROOK: *ext = PAWN_ENDGAME_EXT_2; return *ext;
    default: *ext = PAWN_ENDGAME_EXT_3; return *ext;
    }
  }

  if(*ext>PLY) *ext=PLY;
  return *ext;
}
