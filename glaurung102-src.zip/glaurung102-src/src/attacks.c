#include "glaurung.h"

int is_attacked(int square, int side) {
  int sq, tosq, piece, step;
  attack_data_t *a = AttackData-square;

  for(sq=KSQ(side); sq!=PL_END; sq=PL_NEXT(sq)) {
    if(sq>H8) continue;
    piece = Board[sq];
    if(PieceMask[piece]&a[sq].may_attack) {
      if(!SLIDER(piece)) return 1;
      step = a[sq].step;
      for(tosq=sq+step; Board[tosq]==EMPTY&&tosq!=square; tosq+=step);
      if(tosq==square) return 1;
    }
  }
  return 0;
}

int in_check(int side) {
  return is_attacked(KSQ(side), side^1);
}

/*
   fast_in_check() is a cheap alternative to in_check().  It tests whether
   the side to move is in check, by looking at the from and to squares of
   the move just made.  This function does not work at the root (Ply==0)!
*/
int fast_in_check(void) {
  int ksq=KSQ(Side);
  int from=FROM(SearchStack[Ply-1].move), to=TO(SearchStack[Ply-1].move);
  int piece=Board[to];
  attack_data_t *a = AttackData-ksq;
  if(a[to].may_attack&PieceMask[piece]) {
    if(SLIDER(piece)) {
      int step = a[to].step, sq;
      for(sq=to+step; Board[sq]==EMPTY; sq+=step);
      if(sq==ksq) return 1;
    }
    else return 1;
  }
  if(a[from].may_attack&Q_MASK) {
    int step = a[from].step, sq;
    for(sq=from+step; Board[sq]==EMPTY; sq+=step);
    if(sq==ksq) {
      for(sq=from-step; Board[sq]==EMPTY; sq-=step);
      if(COLOUR(Board[sq])==XSide && (a[sq].may_attack&PieceMask[Board[sq]]))
        return 1;
    }
  }
  return 0;
}
  

/*
   find_checkers() finds all checking pieces (0, 1 or 2).  The return value
   is the number of checking pieces, the two entries of the chsqs aray are
   assigned the locations of the checking pieces.
*/
int find_checkers(int chsqs[]) {
  int ksq = KSQ(Side), sq, step, tosq, piece, result=0;
  attack_data_t *a = AttackData-ksq;

  chsqs[0] = chsqs[1] = 0;
  for(sq=KSQ(XSide); sq!=PL_END && result<2; sq=PL_NEXT(sq)) {
    if(sq>H8) continue;
    piece = Board[sq];
    if(PieceMask[piece] & a[sq].may_attack) {
      if(SLIDER(piece)) {
        step = a[sq].step;
        for(tosq=sq+step; Board[tosq]==EMPTY; tosq+=step);
        if(tosq==ksq) chsqs[result++]=sq;
      }
      else chsqs[result++]=sq;
    }
  }
  return result;
}

/*
   fast_find_checkers() is similar to find_checkers, but works only at
   non-root nodes (Ply>0).  It works by inspecting the move leading to the
   current position.
*/
int fast_find_checkers(int chsqs[]) {
  int ksq = KSQ(Side), from, to, piece, result=0;
  move_t m = SearchStack[Ply-1].move;
  attack_data_t *a = AttackData-ksq;

  if(m == 0) return 0;
  if(EP(m) || CASTLING(m) || PROMOTION(m)) return find_checkers(chsqs);
  from = FROM(m), to = TO(m);
  piece = Board[to];
  chsqs[0] = chsqs[1] = 0;
  if(PieceMask[piece] & a[to].may_attack) {
    if(SLIDER(piece)) {
      int step = a[to].step, sq;
      for(sq=to+step; Board[sq]==EMPTY; sq+=step);
      if(sq==ksq) chsqs[result++]=to;
    }
    else chsqs[result++]=to;
  }
  if(a[from].may_attack & Q_MASK) { /* Discovered check possible. */
    int step = a[from].step, sq;
    for(sq=from+step; Board[sq]==EMPTY; sq+=step);
    if(sq==ksq) {
      for(sq=from-step; Board[sq]==EMPTY; sq-=step);
      if(COLOUR(Board[sq])==XSide && (a[sq].may_attack&PieceMask[Board[sq]]))
        chsqs[result++]=sq;
    }
  }
  return result;
}
          
/*
   pinned() tests whether a piece is pinned on the king.  The return value,
   if nonzero, indicates the direction in which it is pinned.
*/
int pinned(int square) {
  int side = COLOUR(Board[square]), ksq = KSQ(side), p1, p2, step, sq;
  attack_data_t *a = AttackData-ksq+square;

  if(!(a->may_attack&Q_MASK)) return 0;

  if(AttackData[square-ksq].may_attack&R_MASK) p1 = ((side^1)<<3)|ROOK;
  else p1 = ((side^1)<<3)|BISHOP;
  p2 = ((side^1)<<3)|QUEEN;

  step = a->step;
  for(sq=square+step; Board[sq]==EMPTY; sq+=step);
  if(sq==ksq) {
    for(sq=square-step; Board[sq]==EMPTY; sq-=step);
    if(Board[sq]==p1 || Board[sq]==p2) return step;
  }
  return 0;
}

/*
   disc_check_candidate() tests whether a piece is a candidate to deliver
   a discovered check.  The return value, if nonzero, indicates the direction
   in which the piece *cannot* move in order to give a discovered check.
*/
int disc_check_candidate(int square) {
  int side = COLOUR(Board[square]), ksq=KSQ(side^1), p1, p2, step, sq;

  attack_data_t *a = AttackData-ksq+square;

  if(!(a->may_attack&Q_MASK)) return 0;

  if(AttackData[square-ksq].may_attack&R_MASK) p1 = (side<<3)|ROOK;
  else p1 = (side<<3)|BISHOP;
  p2 = (side<<3)|QUEEN;

  step = a->step;
  for(sq=square+step; Board[sq]==EMPTY; sq+=step);
  if(sq==ksq) {
    for(sq=square-step; Board[sq]==EMPTY; sq-=step);
    if(Board[sq]==p1 || Board[sq]==p2) return step;
  }
  return 0;
}


