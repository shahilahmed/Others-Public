#include "glaurung.h"

void init_search(void) {
  int side;

  Ply = 0; RootSearchInfo.nodes = 0; SearchStack[0].ms_ptr = MoveStack;
  for(side=WHITE; side<=BLACK; side++) {
    SearchStack[Ply].material[side] = compute_material(side);
    SearchStack[Ply].psq[side] = compute_psq(side);
    SearchStack[Ply].pawns[side] = count_pawns(side);
  }
  SearchStack[Ply].inceval = 
    SearchStack[Ply].material[Side]-SearchStack[Ply].material[XSide]
    + SearchStack[Ply].psq[Side]-SearchStack[Ply].psq[XSide];
  clear_history();
  tt_new_search();
  FIND_CHECKERS();
}

static void check_for_timeout(void) {
  int t;
  static int last_info_time;

  t = get_time() - RootSearchInfo.start_time;
  if(t<1000) last_info_time = 0;
  else if(t-last_info_time>=1000) {
    printf("info nodes " llu_format " nps " llu_format " time %d\n",
           RootSearchInfo.nodes, (RootSearchInfo.nodes*1000ULL)/((uint64) t), 
           t);
    if(EngineOptions.currline)
      print_currline();
    last_info_time = t;
  }
  if(RootSearchInfo.thinking_status!=PONDERING && RootSearchInfo.iteration>=2) {
    if(!RootSearchInfo.infinite && 
       (t > RootSearchInfo.absolute_max_time
        || (RootSearchInfo.root_moves.current == 1 && 
            t > RootSearchInfo.max_time) 
        || (!RootSearchInfo.fail_high && t > 6*RootSearchInfo.max_time)))
      RootSearchInfo.thinking_status = ABORTED;
    if(RootSearchInfo.node_limit && 
       RootSearchInfo.nodes >= RootSearchInfo.node_limit)
      RootSearchInfo.thinking_status = ABORTED;
    if(RootSearchInfo.exact_time && t >= RootSearchInfo.exact_time)
      RootSearchInfo.thinking_status = ABORTED;
  }
}
    
void init_node(void) {
  search_stack_t *ss = SearchStack+Ply;
  RootSearchInfo.nodes++; RootSearchInfo.nodes_since_poll++;
  if(RootSearchInfo.nodes_since_poll >= RootSearchInfo.nodes_between_polls) {
    check_for_input();
    check_for_timeout();
    RootSearchInfo.nodes_since_poll = 0;
  }

  ss->last_moved_piece_hanging = 0;
  ss->pv[Ply] = 0;
  if(!ss->evaluated) {
    ss->eval_vector.king_safety[0] = ss->eval_vector.king_safety[1] = 0;
    ss->eval_vector.passed_pawns[0] = ss->eval_vector.passed_pawns[1] = 0;
  }
  ss->reduction = 0;
  (ss+1)->pv[Ply+1] = 0;
  (ss+2)->killer = (ss+2)->killer2 = (ss+2)->mate_killer = 0;

  FIND_CHECKERS();
}

void update_pv(move_t m) {
  search_stack_t *ss = SearchStack+Ply;
  int i;
  for(i=Ply+1; (ss+1)->pv[i] != 0; i++) ss->pv[i] = (ss+1)->pv[i];
  ss->pv[i] = 0;
  ss->pv[Ply] = m;
}

static int ok_to_reduce(move_t m) {
  if(PROMOTION(m)) return 0;
  if(CAPTURE(m)) return 0;
  if(m == SearchStack[Ply-1].killer || m == SearchStack[Ply-1].killer2)
    return 0;
  if(Ply >= 3 && (m == SearchStack[Ply-3].killer ||
                  m == SearchStack[Ply-3].killer2)) return 0;
  return 1;
}

static int static_nullmove_test(int depth, int beta, int ks_delta) {
  int margin;
  if(!EngineOptions.static_pruning) return 0;
  if(depth <= PLY) margin = 0;
  else margin = (depth>>5)*120;
  if(depth <= EngineOptions.pruning_depth * PLY && Ply >= 5 &&
     ks_delta > -50 &&
     !SearchStack[Ply-1].extension &&
     !SearchStack[Ply-2].extension &&
     !global_swabbing(XSide, SearchStack[Ply].eval-beta-margin))
    return 1;
  else return 0;
}

static inline int choose_R(void) {
  search_stack_t *ss = SearchStack+Ply;
  if(ss->material[WHITE] + ss->material[BLACK] - 
     (ss->pawns[WHITE] + ss->pawns[BLACK])*P_VALUE <= 4*R_VALUE)
    return 2;
  else
    return 3;
}

int QNodes;

int search(int alpha, int beta, int depth, int follow_pv, int nullmove) {
  int bestvalue, value, nullvalue, legal_moves=0, mate_threat=0, ext;
  int old_alpha = alpha, old_beta = beta;
  int king_safety_delta, pp_delta;
  int futility_value, futility_margin_1, futility_margin_2;
  move_t move, pvmove, hashmove;
  search_stack_t *ss = SearchStack+Ply;

  ss->pv[Ply] = 0;
  if(RootSearchInfo.thinking_status == ABORTED) return 0;
  if(Ply > RootSearchInfo.max_depth) RootSearchInfo.max_depth = Ply;
  if(alpha > MATE_VALUE - Ply - 1) return alpha;

  if(Ply >= 60) return evaluate();

  if(depth<PLY) {
    QNodes=0;
    return qsearch(alpha, beta, depth, follow_pv, Ply);
  }
  if(draw()) return DRAW_VALUE;

  retrieve_tt(&alpha, &beta, depth, &hashmove, &mate_threat, &nullmove);
  if(old_beta-old_alpha!=1) {
    alpha = old_alpha; beta = old_beta;
  }
  if(alpha >= beta) {
    ss->move = hashmove;
    return alpha;
  }
  if(follow_pv) pvmove = SearchStack[0].pv[Ply]; else pvmove = 0;
  if(hashmove && !pvmove) pvmove = hashmove;

  init_node();

  if(!ss->evaluated) {
    ss->eval = evaluate();
    ss->evaluated = 1;
  }

  king_safety_delta = 
    ss->eval_vector.king_safety[Side] - (ss-1)->eval_vector.king_safety[Side];
  pp_delta =
    ss->eval_vector.passed_pawns[XSide] - 
    (ss-1)->eval_vector.passed_pawns[XSide];

  if((ss-1)->reduction && (king_safety_delta < -128 || pp_delta >= 64))
    return alpha - 1;

  if(EngineOptions.learning) {
    move_t lmove, lpmove;
    int lscore;
    if(get_learning_data(Pos.key, depth, &lmove, &lpmove, &lscore)) {
      ss->move = ss->pv[Ply] = lmove; 
      ss->pv[Ply+1] = lpmove; ss->pv[Ply+2] = 0;
      return lscore;
    }
  }

  if(nullmove && !ss->check && !mate_threat && ss->eval >= beta &&
     ss->material[WHITE]>0 && ss->material[BLACK]>0 
     && !pawn_endgame() && 
     !(ss->pawns[Side] == 0 && ss->material[Side] <= R_VALUE)) {
    if(static_nullmove_test(depth, beta, king_safety_delta)) return beta;
    else {
      int R = choose_R();
      make_nullmove();
      nullvalue = -search(-beta, -beta+1, depth-(R+1)*PLY, 0, 0);
      unmake_nullmove();
      if(nullvalue >= beta) {
        if(depth >= 7*PLY && ss->material[Side] <= Q_VALUE + N_VALUE) {
          int v = search(alpha, beta, depth - 6*PLY, 0, 0);
          if(v >= beta) return nullvalue;
        }
        else return nullvalue;
      }
      else {
        if(nullvalue <= -MATE_VALUE+Ply+2) mate_threat = 1;
        ss->threat_move = (ss+1)->move;
        if((ss-1)->reduction && FROM(ss->threat_move) == TO((ss-1)->move))
          return alpha-1;
      }
    }
  }

  if(!pvmove && ((beta-alpha > 1 && depth > 3*PLY) ||
                 (depth > 6*PLY && ss->eval > alpha - 2*P_VALUE))) {
    value = search(alpha, beta, depth-2*PLY, 0, 0);
    if(value >= max(beta, MATE_VALUE-100)) return value;
    if(value < min(alpha, -MATE_VALUE+100)) return value;
    if((ss-1)->reduction && value < alpha) return value;
    pvmove = SearchStack[Ply].pv[Ply];
  }

  if(ss->check) {
    generate_check_evasions();
    if(ss->num_of_evasions==0) return -MATE_VALUE+Ply;
  }
  else generate_moves();

  order_moves(pvmove);

  if((ss-1)->reduction && !ss->last_moved_piece_hanging &&
     ss->eval <= alpha + P_VALUE && (ss->eval < -(ss-1)->eval))
    return alpha-1;

  bestvalue = -MATE_VALUE-1;

  while((move = pick_move())) {
    if(is_legal(move)) {
      legal_moves++;

      /* Futility pruning */
      futility_value = approx_eval_after_move(move); // * 2;
      if(ss->material[WHITE] + ss->material[BLACK] > 2*Q_VALUE+2*N_VALUE) {
        futility_margin_1 = 2*P_VALUE; futility_margin_2 = 6*P_VALUE;
      } 
      else {
        futility_margin_1 = 4*P_VALUE; futility_margin_2 = 12*P_VALUE;
      } 

      if(!ss->check && !is_check(move) && 
         !PROMOTION(move) && !pawn_push_to_7th(move) && 
         ss->eval > -KNOWN_WIN && !PROMOTION((ss-1)->move) &&
         !pawn_push_to_6th(move) && !mate_threat &&
         !((ss-1)->ext_reason&MATE_THREAT_EXT_MASK)) {
        if(depth < 3*PLY && futility_value < alpha-futility_margin_2) continue;
        if(depth < 2*PLY && futility_value < alpha-futility_margin_1) continue;
      }
         
      make_move(move);
      ext = extend(move, &(ss->extension), &(ss->ext_reason), mate_threat,
                   king_safety_delta);

      if(legal_moves==1) {
        value = -search(-beta, -alpha, depth-PLY+ext, follow_pv, 1);
      }
      else {
        if(!ext && legal_moves >= 4 && depth >= 2*PLY && ok_to_reduce(move)) {
          ss->reduction = 1;
          value = -search(-alpha-1, -alpha, depth-2*PLY, 0, 1);
          ss->reduction = 0;
        }
        else value = alpha+1; /* HACK */
        if(value > alpha) {
          value = -search(-alpha-1, -alpha, depth-PLY+ext, 0, 1);
          if(value > alpha && value < beta) {
            value = -search(-beta, -alpha, depth-PLY+ext, 0, 1);
          }
        }
      }
      unmake_move(move);
      if(value > bestvalue) {
        bestvalue = value;
        if(value > alpha) {
          alpha = value; 
          update_pv(move);
          if(value >= beta) {
            inc_history(move, Side, depth, value);
            break;
          }
        }
      }
    }
  }
  if(legal_moves==0) return DRAW_VALUE;

  if(RootSearchInfo.thinking_status == ABORTED) return 0;

  if(bestvalue >= beta) 
    store_tt(bestvalue, depth, ss->pv[Ply], LOWER_BOUND, mate_threat);
  else if(alpha == old_alpha) 
    store_tt(bestvalue, depth, 0, UPPER_BOUND, mate_threat);
  else 
    store_tt(bestvalue, depth, ss->pv[Ply], EXACT, mate_threat);

  return alpha;
}


int qsearch(int alpha, int beta, int depth, int follow_pv, int check_depth) {
  int bestvalue, value, moves=0, mate_threat=0, nullmove;
  int old_alpha = alpha, old_beta = beta;
  int search_checks;
  move_t move, pvmove, hashmove = 0;
  search_stack_t *ss = SearchStack+Ply;

  ss->pv[Ply] = 0;
  if(RootSearchInfo.thinking_status == ABORTED) return 0;

  if(Ply > RootSearchInfo.max_depth) RootSearchInfo.max_depth = Ply;
  if(alpha > MATE_VALUE - Ply - 1) return alpha;

  QNodes++;
  if(Ply >= 60) return evaluate();
  if(draw()) return DRAW_VALUE;

  if(Ply <= check_depth && QNodes < 400 && 
     depth > -EngineOptions.qs_checks * PLY && alpha < 2*N_VALUE)
    search_checks = 1;
  else
    search_checks = 0;

  if(search_checks) {
    retrieve_tt(&alpha, &beta, 0, &hashmove, &mate_threat, &nullmove);
    if(old_beta-old_alpha!=1) {
      alpha = old_alpha; beta = old_beta;
    }
    if(alpha >= beta) {
      ss->move = hashmove;
      return alpha;
    }
  }
  if(follow_pv) pvmove = SearchStack[0].pv[Ply]; else pvmove = 0;
  if(hashmove && !pvmove) pvmove = hashmove;

  init_node();
  if(!ss->evaluated) {
    ss->eval = evaluate();
    ss->evaluated = 1;
  }

  if(ss->check) {
    generate_check_evasions();
    if(ss->num_of_evasions==0) return -MATE_VALUE+Ply;
    if(ss->num_of_evasions==1) check_depth+=2;
    bestvalue = -MATE_VALUE-1;
  }
  else {
    if(ss->eval >= beta) return ss->eval;
    if(ss->eval > alpha) alpha = ss->eval;
    generate_captures();
    bestvalue = ss->eval;
  }
  order_qmoves(pvmove);

  while((move = pick_move())) {
    int futility_value = approx_eval_after_move(move); // * 2;
    int futility_margin;

    if(ss->material[WHITE] + ss->material[BLACK] > 2*Q_VALUE + 2*N_VALUE)
      futility_margin = 100;
    else if(ss->material[WHITE] <= P_VALUE || ss->material[BLACK] <= P_VALUE)
      futility_margin = Q_VALUE;
    else
      futility_margin = 200;

    if(futility_value < alpha-futility_margin && !PROMOTION(move) &&
       !PROMOTION((ss-1)->move) && ss->material[Side] && 
       ss->eval > -KNOWN_WIN &&
       (!search_checks || alpha >= 2*N_VALUE || !is_check(move)))
      continue;
    if(is_legal(move)) {
      if(!ss->check && PieceValues[PIECE(move)] > PieceValues[CAPTURE(move)] 
         && swabbing(FROM(move), TO(move)) < 0)
        continue;
      moves++;

      make_move(move);
      value = -qsearch(-beta, -alpha, depth-PLY, (moves==1)? follow_pv : 0,
                       check_depth);
      unmake_move(move);
      if(value > bestvalue) {
        bestvalue = value;
        if(value > alpha) {
          alpha = value; 
          update_pv(move);
          if(value >= beta) break;
        }
      }
    }
  }
  if(search_checks && alpha < 2*N_VALUE && alpha < beta && !(ss->check)) {
    generate_checks();
    order_moves(pvmove);
    moves=0;
    while((move = pick_move())) {
      if(is_legal(move) && swabbing(FROM(move), TO(move))==0) {
        moves++;
        make_move(move);
        value = -qsearch(-beta, -alpha, depth-PLY, (moves==1)? follow_pv : 0,
                         check_depth);
        unmake_move(move);
        if(value > bestvalue) {
          bestvalue = value;
          if(value > alpha) {
            alpha = value; 
            update_pv(move);
            if(value >= beta) break;
          }
        }
      }
    }
  }
 
  if(RootSearchInfo.thinking_status == ABORTED) return 0;

  if(search_checks) {
    if(bestvalue >= beta) store_tt(bestvalue, 0, ss->pv[Ply], LOWER_BOUND, 0);
    else if(alpha == old_alpha) store_tt(bestvalue, 0, 0, UPPER_BOUND, 0);
    else store_tt(bestvalue, 0, ss->pv[Ply], EXACT, 0);
  }

  return alpha;
}

