#include "glaurung.h"

void generate_moves(void) {
  int from, to, piece, type, tmp, step, rank, prom;
  int *ptr;
  move_stack_t *ms = SearchStack[Ply].ms_ptr;

  for(from=KSQ(Side); from!=PL_END; from=PL_NEXT(from)) {
    if(from>H8) continue;
    piece = Board[from]; type = PIECE_TYPE(piece);
    tmp = (from<<7)|(type<<17);
    if(type==PAWN) {
      step = PawnPush[Side];
      rank = PawnRank[Side][from];
      if(rank < RANK_7) {
        if(Board[from+step]==EMPTY) {
          (ms++)->move = tmp|(from+step);
          if(rank==RANK_2 && Board[from+2*step]==EMPTY)
            (ms++)->move = tmp|(from+2*step);
        }
        for(ptr = Directions[piece]; *ptr; ptr++) {
          to = from + (*ptr);
          if(COLOUR(Board[to])==XSide)
            (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
        }
      } 
      else {
        if(Board[from+step]==EMPTY) 
          for(prom=QUEEN; prom>=KNIGHT; prom--)
            (ms++)->move = tmp|(from+step)|(prom<<14);
        for(ptr = Directions[piece]; *ptr; ptr++) {
          to = from + (*ptr);
          if(COLOUR(Board[to])==XSide) {
            if(PawnRank[Side][to]==RANK_8) {
              for(prom=QUEEN; prom>=KNIGHT; prom--)
                (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20)|(prom<<14);
            }
            else (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
          }
        }
      }
    }
    else {
      for(ptr = Directions[piece]; *ptr; ptr++) {
        if(SLIDER(piece)) {
          to = from;
          do {
            to += (*ptr);
            if(Board[to]==EMPTY || COLOUR(Board[to])==XSide)
              (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
          } while(Board[to]==EMPTY);
        }
        else {
          to = from + (*ptr);
          if(Board[to]==EMPTY || COLOUR(Board[to])==XSide) 
            (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
        }
      }
    }
  }

  /* Finally, we have the ugly special cases of en passant captures and
   * castling moves: */
  if(Pos.ep_square) 
    for(ptr = Directions[EnemyPawn]; *ptr; ptr++) {
      from = Pos.ep_square + (*ptr);
      if(Board[from] == FriendlyPawn)
        (ms++)->move = (Pos.ep_square)|(from<<7)|(PAWN<<17)|(PAWN<<20)|EP_FLAG;
    }

  /* FRC stuff: */
  if(!SearchStack[Ply].check) {
    if(OO_POSSIBLE(Side)) {
      int initialKSQ = InitialKSQ+Side*A8, initialKRSQ = InitialKRSQ+Side*A8;
      int g1 = G1 + Side*A8, f1 = F1 + Side*A8;
      int illegal = 0, sq;
      for(sq = min(initialKSQ, g1); sq <= max(initialKSQ, g1); sq++) 
        if((sq != initialKSQ && sq != initialKRSQ && Board[sq] != EMPTY) ||
           is_attacked(sq, XSide)) 
          illegal = 1; 
      for(sq = min(initialKRSQ, f1); sq <= max(initialKRSQ, f1); sq++)
        if(sq != initialKSQ && sq != initialKRSQ && Board[sq] != EMPTY)
          illegal = 1;
      if(!illegal) (ms++)-> move = (KING<<17)|(initialKSQ<<7)|g1|CASTLE_FLAG;
    }
    if(OOO_POSSIBLE(Side)) {
      int initialKSQ = InitialKSQ+Side*A8, initialQRSQ = InitialQRSQ+Side*A8;
      int c1 = C1 + Side*A8, d1 = D1 + Side*A8;
      int illegal = 0, sq;
      for(sq = min(initialKSQ, c1); sq <= max(initialKSQ, c1); sq++) 
        if((sq != initialKSQ && sq != initialQRSQ && Board[sq] != EMPTY) ||
           is_attacked(sq, XSide)) 
          illegal = 1; 
      for(sq = min(initialQRSQ, d1); sq <= max(initialQRSQ, d1); sq++)
        if(sq != initialKSQ && sq != initialQRSQ && Board[sq] != EMPTY)
          illegal = 1;
      if(InitialQRSQ == B1 && (Board[A1+Side*A8] == EnemyRook ||
                               Board[A1+Side*A8] == EnemyQueen))
        illegal = 1;
      if(!illegal) (ms++)-> move = (KING<<17)|(initialKSQ<<7)|c1|CASTLE_FLAG;
    }
  }

  SearchStack[Ply+1].ms_ptr = ms;
}


void generate_captures(void) {
  int from, to, piece, type, tmp, step, rank;
  int *ptr;
  move_stack_t *ms = SearchStack[Ply].ms_ptr;

  for(from=KSQ(Side); from!=PL_END; from=PL_NEXT(from)) {
    if(from>H8) continue;
    piece = Board[from]; type = PIECE_TYPE(piece);
    tmp = (from<<7)|(type<<17);
    if(type==PAWN) {
      step = PawnPush[Side];
      rank = PawnRank[Side][from];
      if(rank < RANK_7) {
        for(ptr = Directions[piece]; *ptr; ptr++) {
          to = from + (*ptr);
          if(COLOUR(Board[to])==XSide)
            (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
        }
      } 
      else {
        if(Board[from+step]==EMPTY) (ms++)->move = tmp|(from+step)|(QUEEN<<14);
        for(ptr = Directions[piece]; *ptr; ptr++) {
          to = from + (*ptr);
          if(COLOUR(Board[to])==XSide) {
            if(PawnRank[Side][to]==RANK_8) 
              (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20)|(QUEEN<<14);
            else (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
          }
        }
      }
    }
    else if(SLIDER(piece))
      for(ptr = Directions[piece]; *ptr; ptr++) {
        for(to=from+(*ptr); Board[to]==EMPTY; to+=(*ptr));
        if(COLOUR(Board[to])==XSide)
          (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
      }
    else {
      for(ptr = Directions[piece]; *ptr; ptr++) {
        to = from + (*ptr);
        if(COLOUR(Board[to])==XSide) 
          (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
      }
    }
  }

  /* Finally, we have the ugly special case of en passant captures: */
  if(Pos.ep_square) 
    for(ptr = Directions[EnemyPawn]; *ptr; ptr++) {
      from = Pos.ep_square + (*ptr);
      if(Board[from] == FriendlyPawn)
        (ms++)->move = (Pos.ep_square)|(from<<7)|(PAWN<<17)|(PAWN<<20)|EP_FLAG;
    }
  SearchStack[Ply+1].ms_ptr = ms;
}


void generate_check_evasions(void) {
  int ksq = KSQ(Side), from, to, piece, type, tmp, step, rank, prom, pin;
  int checks = SearchStack[Ply].check;
  int *ptr;
  move_stack_t *ms = SearchStack[Ply].ms_ptr;
  
  /* King moves. */
  tmp = (ksq<<7)|(KING<<17);
  Board[ksq]=EMPTY;
  for(ptr=Directions[KING]; *ptr; ptr++) {
    to = ksq+(*ptr);
    if((Board[to]==EMPTY || COLOUR(Board[to])==XSide) && 
       (!is_attacked(to, XSide)))
      (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
  }
  Board[ksq]=FriendlyKing; 

  /* Moves by other pieces are only possible if it is not a double check: */
  if(checks==1) {
    attack_data_t *a = AttackData-ksq;
    int chsq = SearchStack[Ply].checkers[0];
    
    if(SLIDER(Board[chsq])) {
      int blockstep = a[chsq].step;
      for(from=PL_NEXT(ksq); from!=PL_END; from=PL_NEXT(from)) {
        if(from>H8) continue;
        pin = pinned(from);
        piece = Board[from]; type = PIECE_TYPE(piece);
        tmp = (from<<7)|(type<<17);
        if(type==PAWN) {
          step = PawnPush[Side];
          rank = PawnRank[Side][from];
          if(rank < RANK_7) {
            if(!pin || abs(pin)==abs(step)) {
              to = from+step;
              if(Board[to]==EMPTY) {
                if(a[to].step==blockstep && (to-ksq)*(to-chsq)<0)
                  (ms++)->move = tmp|to;
                to += step;
                if(rank==RANK_2 && Board[to]==EMPTY && a[to].step==blockstep
                   && (to-ksq)*(to-chsq)<0)
                  (ms++)->move = tmp|to;
              }
            }
            for(ptr = Directions[piece]; *ptr; ptr++) {
              if(!pin || abs(pin)==abs(*ptr)) {
                to = from + (*ptr);
                if(COLOUR(Board[to])==XSide 
                   && (to==chsq || (a[to].step==blockstep && 
                                    (to-ksq)*(to-chsq)<0)))
                  (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              }
            }
          }
          else {
            to = from+step;
            if(!pin || abs(pin)==abs(step)) 
              if(Board[to]==EMPTY) 
                if(a[to].step==blockstep && (to-ksq)*(to-chsq)<0)
                  for(prom=QUEEN; prom>=KNIGHT; prom--) 
                    (ms++)->move=tmp|to|(prom<<14);
            for(ptr = Directions[piece]; *ptr; ptr++) {
              if(!pin || abs(pin)==abs(*ptr)) {
                to = from + (*ptr);
                if(COLOUR(Board[to])==XSide 
                   && (to==chsq || (a[to].step==blockstep && 
                                    (to-ksq)*(to-chsq)<0))) {
                  if(PawnRank[Side][to]==RANK_8) {
                    for(prom=QUEEN; prom>=KNIGHT; prom--) 
                      (ms++)->move=tmp|to|(PIECE_TYPE(Board[to])<<20)|(prom<<14);
                  }
                  else
                    (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
                }
              }
            }
          }
        } 
        else { /* Not a pawn */
          for(ptr = Directions[piece]; *ptr; ptr++) {
            if(pin && abs(pin) != abs(*ptr)) continue;
            if(SLIDER(piece)) {
              to = from;
              do {
                to += (*ptr);
                if((Board[to]==EMPTY || COLOUR(Board[to])==XSide)
                   && (to==chsq ||
                       (a[to].step==blockstep && (to-ksq)*(to-chsq)<0)))
                  (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              } while(Board[to]==EMPTY);
            }
            else {
              to = from + (*ptr);
              if((Board[to]==EMPTY || COLOUR(Board[to])==XSide)
                 && (to==chsq ||
                     (a[to].step==blockstep && (to-ksq)*(to-chsq)<0)))
                (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
            }
          }
        }
      }
    }
    else { /* Checking piece is not a slider.  Blocking moves impossible. */
      for(from=PL_NEXT(ksq); from!=PL_END; from=PL_NEXT(from)) {
        if(from>H8) continue;
        pin = pinned(from);
        piece = Board[from]; type = PIECE_TYPE(piece);
        tmp = (from<<7)|(type<<17);
        if(type==PAWN) {
          for(ptr = Directions[piece]; *ptr; ptr++) {
            if(!pin || abs(pin)==abs(*ptr)) {
              to = from + (*ptr);
              if(to==chsq) {
                if(PawnRank[Side][to]==RANK_8) {
                  for(prom=QUEEN; prom>=BISHOP; prom--) 
                    (ms++)->move=tmp|to|(PIECE_TYPE(Board[to])<<20)|(prom<<14);
                }
                else (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              }
            }
          }
        }
        else {
          for(ptr = Directions[piece]; *ptr; ptr++) {
            if(pin && abs(pin) != abs(*ptr)) continue;
            if(SLIDER(piece)) {
              to = from;
              do {
                to += (*ptr);
                if(to==chsq)
                  (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              } while(Board[to]==EMPTY);
            }
            else {
              to = from + (*ptr);
              if(to==chsq)
                (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
            }
          }
        }
      }
    }

    /* Finally, we have the ugly special case of en passant captures: */
    if(Pos.ep_square) 
      for(ptr = Directions[EnemyPawn]; *ptr; ptr++) {
        from = Pos.ep_square + (*ptr);
        if(Board[from] == FriendlyPawn) {
          int legal;
          ms->move = (Pos.ep_square)|(from<<7)|(PAWN<<17)|(PAWN<<20)|EP_FLAG;
          make_move(ms->move);
          legal = !in_check(XSide);
          unmake_move(ms->move);
          if(legal) ms++;
        }
      }
  }

  SearchStack[Ply+1].ms_ptr = ms;
  SearchStack[Ply].num_of_evasions = ms-SearchStack[Ply].ms_ptr;
}


/* generate_checks() generates all pseudo-legal non-capturing, non-promoting
 * checks. */
void generate_checks(void) {
  int from, to, to2, piece, type, tmp, step, step2, rank, ksq, mask, dc;
  int *ptr;
  move_stack_t *ms = SearchStack[Ply].ms_ptr;
  attack_data_t *a;
  
  ksq = KSQ(XSide);
  a = AttackData-ksq;
  for(from=KSQ(Side); from!=PL_END; from=PL_NEXT(from)) {
    if(from>H8) continue;
    piece = Board[from]; type = PIECE_TYPE(piece);
    mask = PieceMask[piece];
    tmp = (from<<7)|(type<<17);

    /* An easy optimization would be to replace the following call with
     * in-line code.  The disc_check_candidate function duplicates part
     * of the work done by generate_checks(). */
    dc = disc_check_candidate(from);
    if(type==PAWN) {
      rank = PawnRank[Side][from];
      if(rank<RANK_7) {
        step = PawnPush[Side];
        dc = (dc && abs(dc)!=abs(step));
        to = from+step;
        if(Board[to]==EMPTY) {
          if((a[to].may_attack&mask)|dc) (ms++)->move = tmp|to;
          to+=step;
          if(rank==RANK_2 && Board[to]==EMPTY && ((a[to].may_attack&mask)||dc))
            (ms++)->move = tmp|to;
        }
      }
    }
    else {
      for(ptr = Directions[piece]; *ptr; ptr++) {
        int dc2 = (dc && abs(dc)!=abs(*ptr));
        if(SLIDER(piece)) {
          to = from;
          do {
            to += (*ptr);
            if(Board[to]==EMPTY) {
              if(dc2) (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              else if(a[to].may_attack&mask) {
                step2 = a[to].step;
                for(to2=to+step2; Board[to2]==EMPTY; to2+=step2);
                if(to2==ksq) (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
              }
            }
          } while(Board[to]==EMPTY);
        }
        else {
          to = from + (*ptr);
          if(Board[to]==EMPTY && ((a[to].may_attack&mask)||dc2))
            (ms++)->move = tmp|to|(PIECE_TYPE(Board[to])<<20);
        }
      }
    }
  }

  SearchStack[Ply+1].ms_ptr = ms;
}
