#include "glaurung.h"

position_t Pos;

uint32 FileMask[8] = {1, 2, 4, 8, 16, 32, 64, 128};

int Directions[16][16] = {
  {0},
  {15, 17, 0},  /* WP */
  {33, 31, 18, 14, -14, -18, -31, -33, 0},  /* WN */
  {17, 15, -15, -17, 0},  /* WB */
  {16, 1, -1, -16, 0},  /* WR */
  {17, 16, 15, 1, -1, -15, -16, -17, 0},  /* WQ */
  {17, 16, 15, 1, -1, -15, -16, -17, 0},  /* WK */
  {0},
  {0},
  {-15, -17, 0},  /* BP */
  {-33, -31, -18, -14, 14, 18, 31, 33, 0},  /* BN */
  {-17, -15, 15, 17, 0},  /* BB */
  {-16, -1, 1, 16, 0},  /* BR */
  {-17, -16, -15, -1, 1, 15, 16, 17, 0},  /* BQ */
  {-17, -16, -15, -1, 1, 15, 16, 17, 0},  /* BK */
  {0}
};

int SlidingArray[16] = {0,0,0,1,2,3,0,0,0,0,0,1,2,3,0};

int PawnPush[2] = {16, -16};

uint8 PawnRank[2][128];

attack_data_t AttackData_[256];
attack_data_t *AttackData = AttackData_+128;
int PieceMask[OUTSIDE+1] = {0,WP_MASK,N_MASK,B_MASK,R_MASK,Q_MASK,K_MASK,0,
                            0,BP_MASK,N_MASK,B_MASK,R_MASK,Q_MASK,K_MASK,0,
                            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

uint8 Distance_[256];
uint8 *Distance = Distance_+128;

move_stack_t MoveStack[MOVE_STACK_SIZE];
search_stack_t SearchStack[MAX_DEPTH];

int Ply, GPly=0;

int PieceValues[EMPTY+1] = {
  0, P_VALUE, N_VALUE, B_VALUE, R_VALUE, Q_VALUE, K_VALUE, 0,
  0, P_VALUE, N_VALUE, B_VALUE, R_VALUE, Q_VALUE, K_VALUE, 0, 0
};

uint32 History[2][4096];

root_search_info_t RootSearchInfo;

engine_options_t EngineOptions;

/* FRC stuff: */
int InitialKSQ, InitialKRSQ, InitialQRSQ;
