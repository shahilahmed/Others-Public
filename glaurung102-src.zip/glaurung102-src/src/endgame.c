#include "glaurung.h"

uint8 MateTable[128] = {
  100, 90, 80, 70, 70, 80, 90, 100, 0, 0, 0, 0, 0, 0, 0, 0,
  90, 70, 60, 50, 50, 60, 70, 90, 0, 0, 0, 0, 0, 0, 0, 0,
  80, 60, 40, 30, 30, 40, 60, 80, 0, 0, 0, 0, 0, 0, 0, 0,
  70, 50, 30, 20, 20, 30, 50, 70, 0, 0, 0, 0, 0, 0, 0, 0,
  70, 50, 30, 20, 20, 30, 50, 70, 0, 0, 0, 0, 0, 0, 0, 0,
  80, 60, 40, 30, 30, 40, 60, 80, 0, 0, 0, 0, 0, 0, 0, 0,
  90, 70, 60, 50, 50, 60, 70, 90, 0, 0, 0, 0, 0, 0, 0, 0,
  100, 90, 80, 70, 70, 80, 90, 100, 0, 0, 0, 0, 0, 0, 0, 0
};

int DistanceBonus[8] = {0, 0, 100, 80, 60, 40, 20, 10};

int pawn_endgame(void) {
  return ((SearchStack[Ply].material[WHITE] == 
           SearchStack[Ply].pawns[WHITE] * P_VALUE) &&
          (SearchStack[Ply].material[BLACK] == 
           SearchStack[Ply].pawns[BLACK] * P_VALUE));
}         

int scale_endgame_eval(int scale[], p_hashentry_t *ph) {
  search_stack_t *ss = SearchStack+Ply;
  int winner, loser;

  /* KPK */
  if(ss->material[WHITE] + ss->material[BLACK] == P_VALUE)
    return KPK;
  
  if(ss->material[WHITE] == 0) scale[WHITE] = 0;
  if(ss->material[BLACK] == 0) scale[BLACK] = 0;

  if(ss->material[WHITE] >= ss->material[BLACK]) {
    winner = WHITE; loser = BLACK;
  }
  else {
    winner = BLACK; loser = WHITE;
  }
  
  /* Easy mates of a lone king: */
  if(ss->material[loser] == 0 && ss->material[winner] >= R_VALUE) {
    /* KNNK and KBNK */
    if(ss->material[winner] == 2*N_VALUE) {
      if(PL_START((winner<<3)|BISHOP) > H8) {  /* KNNK, draw. */
        scale[winner] = 0; return 0;
      }
      if(PL_START((winner<<3)|KNIGHT) <= H8) /* KBNK */
        return KBNK;
    }
    /* Other endgames are handled by a generic KXK eval. */
    return KXK;
  }

  /* A minor piece alone cannot win: */
  if(ss->pawns[WHITE] == 0 && ss->material[WHITE] == N_VALUE)
    scale[WHITE] = 0;
  if(ss->pawns[BLACK] == 0 && ss->material[BLACK] == N_VALUE)
    scale[BLACK] = 0;

  /* KQKR */
  if(ss->material[winner] == Q_VALUE && ss->material[loser] == R_VALUE)
    return KQKR;

  /* KRKP */
  if(ss->material[winner] == R_VALUE && ss->material[loser] == P_VALUE)
    return KRKP;

  /* KRPKR */
  if(ss->material[winner] == R_VALUE+P_VALUE && ss->material[loser] == R_VALUE)
    return KRPKR;

  /* KRKN and KRKB */
  if(ss->material[winner] == R_VALUE && ss->material[loser] == N_VALUE) {
    if(PL_START((loser<<3)|KNIGHT) <= H8) return KRKN;
    else return KRKB;
  }

  /* KBPK draw with rook pawn and wrong bishop: */
  if(ss->material[winner] == B_VALUE+P_VALUE && /*ss->material[loser] == 0 &&*/
     PL_START((winner<<3)|BISHOP) <= H8 && 
     (ph->open_files[winner] == 254 || ph->open_files[winner] == 127)) {
    int bsq = PL_START((winner<<3)|BISHOP);
    int psq = PL_START((winner<<3)|PAWN), ksq = KSQ(loser);
    int queening_sq = H1*(ph->open_files[winner]&1)+loser*A8;

    if(SquareColour[queening_sq] != SquareColour[bsq]) {
      if(PawnRank[winner][psq] < PawnRank[winner][ksq] &&
         abs(file(ksq) - file(psq)) <= 1) {
        scale[winner] = 0; return 0;
      }
      else if(Distance[ksq-queening_sq] <= 1) {
        scale[winner] = 0; return 0;
      }
    }
  }

  /* KRPP vs KRP without a passed pawn is usually a draw if the defending *
   * king is in the path of the pawns: */
  if(ss->material[winner] == R_VALUE + P_VALUE + P_VALUE &&
     ss->material[loser] == R_VALUE + P_VALUE &&
     ph->passed_pawn_squares[winner][0] == 0) {
    int psq1 = PL_START((winner<<3)|PAWN), psq2 = PL_NEXT(psq1);
    int rank1 = PawnRank[winner][psq1], rank2 = PawnRank[winner][psq2];
    int ksq = KSQ(loser);
    if(abs(file(psq1) - file(ksq)) <= 1 && abs(file(psq2) - file(ksq)) <= 1 &&
       PawnRank[winner][ksq] > rank1 &&
       PawnRank[winner][ksq] > rank2); {
      switch(max(rank1, rank2)) {
      case RANK_3: case RANK_2: scale[winner] = 30; break;
      case RANK_4: scale[winner] = 40; break;
      case RANK_5: scale[winner] = 70; break;
      case RANK_6: scale[winner] = 128; break;
      }
      return 0;
    }
  }

  /* KBP vs KN or KB is a draw when the defending king blocks the pawn and *
   * cannot be driven away by the bishop. */
  if(ss->material[winner] == B_VALUE + P_VALUE &&
     ss->material[loser] >= B_VALUE &&
     PL_START((winner<<3)|BISHOP) <= H8) {
    int bsq = PL_START((winner<<3)|BISHOP);
    int psq = PL_START((winner<<3)|PAWN);
    int ksq = KSQ(loser);
    if(file(ksq) == file(psq) && PawnRank[winner][psq] < PawnRank[winner][ksq]
       && (SquareColour[ksq] != SquareColour[bsq] || 
           PawnRank[winner][ksq] <= RANK_6)) {
      scale[winner] = 0; return 0;
    }
  }

  /* KBP vs KB with opposite-colored bishops is almost always a draw: */
  if(ss->material[winner] == B_VALUE + P_VALUE &&
     ss->material[loser] == B_VALUE) {
    int bsq1 = PL_START((winner<<3)|BISHOP);
    int bsq2 = PL_START((loser<<3)|BISHOP);
    if(bsq1 <= H8 && bsq2 <= H8 && SquareColour[bsq1] != SquareColour[bsq2]) {
      int psq = PL_START((winner<<3)|PAWN);
      int prank = PawnRank[winner][psq];
      if(prank <= RANK_5) {
        scale[winner] = 0; return 0;
      }
      else {
        int sq, step = PawnPush[winner];
        for(sq = psq + step; Board[sq] != OUTSIDE; sq += step) {
          if(Board[sq] == ((loser<<3)|KING)) {
            scale[winner] = 0; return 0;
          }
          if(attacked_by_non_king(sq, loser) &&
             DISTANCE(bsq2, psq) >= 3) {
            scale[winner] = 0; return 0;
          }
        }
      }
    }
  }

  /* Without pawns, it is hard to win with only a minor piece up: */
  if(ss->pawns[winner] == 0 && scale[winner] > 0 &&
     ss->material[winner]-ss->material[loser] <= B_VALUE) {
    if(ss->material[winner] == ss->material[loser]) {
      scale[winner] = 0;
      if(ss->pawns[loser] == 0) scale[loser] = 0;
      return 0;
    }
    if(ss->material[winner] == R_VALUE + B_VALUE &&
       PL_START((loser<<3)|ROOK) <= H8) {
      if(PL_START((winner<<3)|BISHOP) <= H8) {  /* KRBKR */
        scale[winner] = 32; scale[loser] = 0; 
        return 0;
      }
      else {  /* KRNKR */
        scale[winner] = 8; scale[loser] = 0;
        return 0;
      }
    }
    scale[winner] = 64; 
    if(ss->pawns[loser] == 0) scale[loser] = 0; 
    return 0;
  }

  return 0;
}


uint8 KPK_bitbase[24576];

void init_kpk(void) {
  FILE *f = fopen("kpk.bin", "rb");
  int i;
  if(f == NULL) {
    printf("kpk.bin not found!\n");
    quit();
  }
  for(i = 0; i < 24576; i++) KPK_bitbase[i] = fgetc(f);
  fclose(f);
}

int probe_kpk(int wksq, int wpsq, int bksq, int side) {
  int index;
  wksq = COMPRESS(wksq); bksq = COMPRESS(bksq);
  wpsq = (wpsq & 3) + ((wpsq / 16) - 1) * 4;
  index = side + 2*bksq + 128*wksq + 8192*wpsq;
  return (KPK_bitbase[index/8] & (1<<(index&7)));
}

int kpk_eval(void) {
  int wksq, wpsq, bksq, side, sign;

  sign = SearchStack[Ply].pawns[Side]? 1 : -1;

  if(SearchStack[Ply].pawns[WHITE]) {
    wksq = KSQ(WHITE); wpsq = PL_START(WP); bksq = KSQ(BLACK); side = Side;
  }
  else {
    wksq = KSQ(BLACK) ^ 0x70; wpsq = PL_START(BP) ^ 0x70;
    bksq = KSQ(WHITE) ^ 0x70; side = Side^1;
  }
  if(file(wpsq) >= FILE_E) {
    wpsq ^= 7; wksq ^=7; bksq ^= 7;
  }
  if(probe_kpk(wksq, wpsq, bksq, side))
    return sign * (KNOWN_WIN + P_VALUE + rank(wpsq));

  return 0;
}
  
int krkb_eval(void) {
  int defender =(SearchStack[Ply].material[WHITE] == R_VALUE)? BLACK : WHITE;

  if(defender == Side) return -MateTable[KSQ(defender)];
  else return MateTable[KSQ(defender)];
}

int KNDistancePenalty[8] = {0, 0, 4, 10, 20, 32, 48, 70};

int krkn_eval(void) {
  int defender =(SearchStack[Ply].material[WHITE] == R_VALUE)? BLACK : WHITE;
  int attacker = defender^1;
  int defending_ksq = KSQ(defender);
  int nsq=PL_START((defender<<3)|KNIGHT);
  int result;

  result = 10 + MateTable[defending_ksq] 
    + KNDistancePenalty[Distance[defending_ksq - nsq]];

  return(attacker == Side)? result : -result;
}

#define KRKP_WIN (R_VALUE-Distance[wksq-bpsq])
  
int krkp_eval(void) {
  int winner = (SearchStack[Ply].pawns[BLACK])? WHITE : BLACK;
  int loser = winner^1;
  int wksq, wrsq, bksq, bpsq, qsq, tempo, sign;

  wksq = KSQ(winner); wrsq = PL_START((winner<<3)|ROOK);
  bksq = KSQ(loser); bpsq = PL_START((loser<<3)|PAWN);
  if(winner == BLACK) {
    wksq ^= 0x70; wrsq ^= 0x70; bksq ^= 0x70; bpsq ^= 0x70;
  }
  qsq = file(bpsq);   /* Queening square */
  tempo = (Side == winner)? 1 : 0;
  sign = tempo? 1 : -1;
  
  if(wksq<bpsq && file(wksq)==file(bpsq))
    return sign * KRKP_WIN;
  if(Distance[wksq-qsq] + 1 - tempo < Distance[bksq-qsq])
    return sign * KRKP_WIN;
  if(Distance[bksq-bpsq]-(tempo^1) >= 3 && Distance[bksq-wrsq] >= 3)
    return sign * KRKP_WIN;
  if(rank(bpsq) <= RANK_3 && Distance[bksq-bpsq] == 1 && rank(wksq) >= RANK_4
     && Distance[wksq-bpsq] - tempo > 2)
    return sign * (80-Distance[wksq-bpsq]*8);

  return sign * (200 
                 + KingActivityBonus[bpsq-wksq+128]
                 - KingActivityBonus[bpsq-bksq+128]
                 + Distance[bpsq-qsq]*8);
}

uint8 KBNKtable[128] = {
  200, 190, 180, 170, 160, 150, 140, 130, 0, 0, 0, 0, 0, 0, 0, 0,
  190, 180, 170, 160, 150, 140, 130, 140, 0, 0, 0, 0, 0, 0, 0, 0,
  180, 170, 155, 140, 140, 125, 140, 150, 0, 0, 0, 0, 0, 0, 0, 0,
  170, 160, 140, 120, 110, 140, 150, 160, 0, 0, 0, 0, 0, 0, 0, 0,
  160, 150, 140, 110, 120, 140, 160, 170, 0, 0, 0, 0, 0, 0, 0, 0,
  150, 140, 125, 140, 140, 155, 170, 180, 0, 0, 0, 0, 0, 0, 0, 0,
  140, 130, 140, 150, 160, 170, 180, 190, 0, 0, 0, 0, 0, 0, 0, 0,
  130, 140, 150, 160, 170, 180, 190, 200, 0, 0, 0, 0, 0, 0, 0, 0
};

int kbnk_eval(void) {
  int winner, loser;
  int wksq, bksq, bsq, nsq, side, sign;
  
  winner = SearchStack[Ply].material[WHITE]? WHITE : BLACK;
  loser = winner^1;
  sign = (winner == Side)? 1 : -1;
  side = (winner == Side)? WHITE : BLACK;

  wksq = KSQ(winner); bksq = KSQ(loser);
  bsq = PL_START((winner<<3)|BISHOP); nsq = PL_START((winner<<3)|KNIGHT);

  if((file(bsq) + rank(bsq)) % 2) {
    wksq ^= 7; bksq ^= 7; bsq ^= 7; nsq ^= 7;
  }
  
  return sign*(KNOWN_WIN + DistanceBonus[Distance[wksq-bksq]] +
               KBNKtable[bksq]);
}
  
int kxk_eval(void) {
  int winner = SearchStack[Ply].material[WHITE]? WHITE : BLACK;
  int loser = winner^1;
  int result;

  result = (SearchStack[Ply].material[winner] 
            + MateTable[KSQ(loser)]
            + DistanceBonus[DISTANCE(KSQ(winner), KSQ(loser))]);

  if(PL_START((winner<<3)|QUEEN) <= H8 || PL_START((winner<<3)|ROOK) <= H8 ||
     SearchStack[Ply].material[winner] >= 8*P_VALUE)
    result += KNOWN_WIN;

  return (winner==Side)? result : -result;
}

int KRPKRkingFileProximityBonus[11] = {
  -168, -144, -120, -96, -72, 0, 48, 128, 96, 24, -17
};

int krpkr_eval(void) {
  int winner = SearchStack[Ply].pawns[WHITE]? WHITE : BLACK;
  int loser = winner^1;
  int wksq, wrsq, wpsq, bksq, brsq, qsq;
  int file, rank;
  int tempo;
  int result;

  wksq = KSQ(winner); wrsq = PL_START((winner<<3)|ROOK);
  wpsq = PL_START((winner<<3)|PAWN);
  bksq = KSQ(loser); brsq = PL_START((loser<<3)|ROOK);

  if(winner == BLACK) {
    wksq ^= 0x70; wrsq ^= 0x70; wpsq ^= 0x70; bksq ^= 0x70; brsq ^= 0x70;
  }
  if(file(wpsq) > FILE_D) {
    wksq ^= 7; wrsq ^= 7; wpsq ^= 7; bksq ^= 7; brsq ^= 7;
  }
  
  file = file(wpsq); rank = rank(wpsq); qsq = file + A8;
  tempo = (Side==winner)? 1 : 0;

  /* Some simple special cases first.  If the pawn is not too far advanced
   * and the defending king defends the queening square, use the third-rank
   * defence. */
  if(rank <= RANK_5 && Distance[bksq-qsq] <= 1 && wksq <= H5) {
    if(rank(brsq) == RANK_6) return 0;
    if(rank <= RANK_3 && rank(wrsq) != RANK_6) return 0;
  }

  /* The defending side saves a draw by checking from behind in case the
   * pawn has advanced to the 6th rank with the king behind */
  if(rank == RANK_6 && Distance[bksq-qsq] <= 1 && rank(wksq)+tempo <= RANK_6
     && (rank(brsq) == RANK_1 ||
         (!tempo && abs(file(brsq) - file) >= 3)))
    return 0;

  if(rank >= RANK_6 && bksq == qsq && rank(brsq) == RANK_1 && 
     (!tempo || Distance[wksq-wpsq] >= 2))
    return 0;

  /* White pawn on a7 and rook on a8 is a draw if black's king is on
   * g7 or h7 and the black rook is behind the pawn */
  if(wpsq==A7 && wrsq==A8 && (bksq==H7 || bksq==G7) && 
     (brsq==A1 || brsq==A2 || brsq==A3 || 
      (file(brsq)==FILE_A && (file(wksq) >= FILE_D
                              || rank(wksq) <= RANK_5))))
    return 0;
  
  /* Pawn on the 7th rank supported by the rook from behind wins if
   * the attacking king is closer to the queening square than the 
   * defending king, and the defending king cannot gain tempi by 
   * threatening the attacking rook. */
  if(rank == RANK_7 && file != FILE_A && file(wrsq)==file && wrsq != wpsq+16 &&
     Distance[wksq-qsq] < Distance[bksq-qsq]-2 + tempo &&
     Distance[wksq-qsq] < Distance[bksq-wrsq] + tempo)
    return (R_VALUE-Distance[wksq-qsq]+tempo);

  /* Similar to the above, but with pawn further back. */
  if(file != FILE_A && file(wrsq)==file && wrsq < wpsq &&
     Distance[wksq-qsq] < Distance[bksq-qsq]-2 + tempo &&
     Distance[wksq-wpsq-16] < Distance[bksq-wpsq-16]-2 + tempo &&
     (Distance[bksq-wrsq] + tempo >= 3 ||
      (Distance[wksq-qsq] < Distance[bksq-wrsq] + tempo &&
       Distance[wksq-wpsq-16] < Distance[bksq-wrsq] + tempo))) {
  }
  if(file != FILE_A && file(wrsq)==file && wrsq < wpsq &&
     Distance[wksq-qsq] < Distance[bksq-qsq]-1 + tempo &&
     Distance[wksq-wpsq-16] < Distance[bksq-wpsq-16]-1 + tempo &&
     (Distance[bksq-wrsq] + tempo >= 3 ||
      (Distance[wksq-qsq] < Distance[bksq-wrsq] + tempo &&
       Distance[wksq-wpsq-16] < Distance[bksq-wrsq] + tempo))) {
    return (P_VALUE - Distance[wksq-qsq]*4 + rank*64);
  }

  /* If the defending king blocks the pawn and the attacking king is too
   * far away, it's a draw. */
  if(rank <= RANK_5 && bksq == wpsq + 16 && Distance[wksq-wpsq]-tempo >= 2 && 
     Distance[wksq-brsq]-tempo >= 2)
    return 0;

  /* More special cases should be added.  Some general code follows. */

  /* Initial bonus by rank.  Reduce bonus for rook pawn. */
  result = rank*4 + P_VALUE;
  if(file == FILE_A) result -= 60;

  /* The defending rook should try to be as far from the pawn as possible. */
  result -= 4*Distance[wpsq-brsq] + 6*abs(file(brsq)-file);

  /* The defending king should try to be in front of the pawn.  It is best 
   * to keep it on the "short side" of the pawn. */
  if(rank(bksq) >= rank) 
    result -= KRPKRkingFileProximityBonus[file-file(bksq)+7];
  else
    result += 40*(rank-rank(bksq));

  /* If the attacking king is behind the pawn, the winning chances are 
   * smaller. */
  if(rank(wksq) < rank) result -= 16*(rank-rank(wksq));

  /* The defending rook behind the pawn reduces winning chances. */
  if(brsq < wpsq && file(brsq) == file) result -= 40;

  /* Stretch big scores. */
  if(result > P_VALUE) result += (result-P_VALUE)*4; 

  return tempo? result : -result;
}

int kqkr_eval(void) {
  int winner = (SearchStack[Ply].material[WHITE] == Q_VALUE)? WHITE : BLACK;
  return (Q_VALUE - R_VALUE + MateTable[KSQ(winner^1)] 
          + DistanceBonus[DISTANCE(KSQ(winner), KSQ(winner^1))]);
}

  
