#include "glaurung.h"

void clear_history(void) {
  int i;
  for(i=0; i<4096; i++) History[0][i] = History[1][i] = 0;
}

void inc_history(move_t m, int side, int depth, int value) {
  if(!CAPTURE(m) && !PROMOTION(m)) {
    HISTORY(side, m) += (depth>>5);
    SearchStack[Ply].killer2 = SearchStack[Ply].killer;
    SearchStack[Ply].killer = m;
  }
  if(value==MATE_VALUE-Ply-1) SearchStack[Ply].mate_killer = m;
}
