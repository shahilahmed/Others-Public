#include "glaurung.h"

char *move2str(move_t move, char *str) {
  char letters[BK+2] = " pnbrqk  pnbrqk";
  if(move == NULLMOVE) sprintf(str, "0000");
  else if(EngineOptions.frc && SHORT_CASTLING(move))
    sprintf(str, "%c%c%c%c",
            (char)file(FROM(move))+'a', (char)rank(FROM(move))+'1',
            (char)file(InitialKRSQ)+'a',(char)rank(TO(move))+'1');
  else if(EngineOptions.frc && LONG_CASTLING(move))
    sprintf(str, "%c%c%c%c",
            (char)file(FROM(move))+'a', (char)rank(FROM(move))+'1',
            (char)file(InitialQRSQ)+'a',(char)rank(TO(move))+'1');
  else if(PROMOTION(move))
    sprintf(str, "%c%c%c%c%c", 
            (char)file(FROM(move))+'a', (char)rank(FROM(move))+'1',
            (char)file(TO(move))+'a', (char)rank(TO(move))+'1',
            (char)letters[PROMOTION(move)]);
  else sprintf(str, "%c%c%c%c", 
               (char)file(FROM(move))+'a', (char)rank(FROM(move))+'1',
               (char)file(TO(move))+'a', (char)rank(TO(move))+'1');
  return str;
}

void print_move(move_t move) {
  char str[6];
  move2str(move, str);
  printf("%s ", str);
}

void print_pv(move_t pv[], int depth, int score, int num) {
  int i, t, seldepth;
  static int last_score;

  if(depth > 60) return;

  seldepth = max(depth, RootSearchInfo.max_depth);

  if(RootSearchInfo.thinking_status == ABORTED)
    score = last_score; 
  else
    last_score = score;

  t = get_time()-RootSearchInfo.start_time;
  if(abs(score) < MATE_VALUE - 300)
    printf("info multipv %d depth %d seldepth %d score cp %d time %d nodes " llu_format " " ,
           num, depth, seldepth, (score*100)/P_VALUE, t, RootSearchInfo.nodes);
  else 
    printf("info multipv %d depth %d seldepth %d score mate %d time %d nodes " llu_format " ",
           num, depth, seldepth, (score>0)? (MATE_VALUE-score+1)/2 : -(MATE_VALUE+score)/2,
           t, RootSearchInfo.nodes);
  if(t > 0) printf("nps " llu_format " ", 
		   (RootSearchInfo.nodes*1000ULL)/((uint64) t));
  printf("pv ");
    
  for(i = 0; pv[i]; i++) print_move(pv[i]);
  printf("\n");
}

void print_multipv(void) {
  int i, k;

  k = min(RootSearchInfo.root_moves.num, EngineOptions.multipv);
  for(i = 0; i < k; i++) 
    print_pv(RootSearchInfo.root_moves.moves[i].pv,
             RootSearchInfo.root_moves.moves[i].depth,
             RootSearchInfo.root_moves.moves[i].score,
             i + 1);
}

void print_currline(void) {
  int i;
  printf("info currline ");
  for(i = 0; i < Ply; i++) print_move(SearchStack[i].move);
  printf("\n");
}

void set_position(char *fen) {
  int sq;
 
  init_board();
  for(sq = A8; sq >= A1; fen++) {
    if(*fen == '\0') {printf("Error!\n"); return; }
    if(isdigit(*fen)) {sq += (*fen) - '1' + 1; continue;}
    switch(*fen) {
    case 'K': Pos.board[sq] = WK; break;
    case 'k': Pos.board[sq] = BK; break;
    case 'Q': Pos.board[sq] = WQ; break;
    case 'q': Pos.board[sq] = BQ; break;
    case 'R': Pos.board[sq] = WR; break;
    case 'r': Pos.board[sq] = BR; break;
    case 'B': Pos.board[sq] = WB; break;
    case 'b': Pos.board[sq] = BB; break;
    case 'N': Pos.board[sq] = WN; break;
    case 'n': Pos.board[sq] = BN; break;
    case 'P': Pos.board[sq] = WP; break;
    case 'p': Pos.board[sq] = BP; break;
    case '/': sq -= file(sq) + 16; break;
    case ' ': sq=A1-1; break;
    default: printf("Error!\n"); return; 
    }
    if(strchr(" /", *fen) == NULL) sq++;
  }
  switch(tolower(*fen)) {
  case 'w': Side = WHITE; XSide = BLACK; break;
  case 'b': Side = BLACK; XSide = WHITE; break;
  default: printf("Error!\n"); return; 
  }
  do {fen++;} while(isspace(*fen));

  init_piece_lists();

  Pos.castle_flags = W_OO_MASK | W_OOO_MASK | B_OO_MASK | B_OOO_MASK;
  while(*fen != '\0' && !isspace(*fen)) {
    if(*fen == 'K') {
      Pos.castle_flags ^= W_OO_MASK;
      InitialKSQ = E1; InitialKRSQ = H1;
    }
    else if(*fen == 'Q') {
      Pos.castle_flags ^= W_OOO_MASK;
      InitialKSQ = E1; InitialQRSQ = A1;
    }
    else if(*fen == 'k') {
      Pos.castle_flags ^= B_OO_MASK;
      InitialKSQ = E1; InitialKRSQ = H1;
    }
    else if(*fen == 'q') {
      Pos.castle_flags ^= B_OOO_MASK;
      InitialKSQ = E1; InitialQRSQ = A1;
    }
    else if(*fen >= 'A' && *fen <= 'H') {
      InitialKSQ = KSQ(WHITE);
      sq = (int) (*fen) - (int) 'A';
      if(sq > KSQ(WHITE)) {
        Pos.castle_flags ^= W_OO_MASK;
        InitialKRSQ = sq;
      }
      else {
        Pos.castle_flags ^= W_OOO_MASK;
        InitialQRSQ = sq;
      }
    }
    else if(*fen >= 'a' && *fen <= 'h') {
      InitialKSQ = KSQ(WHITE);
      sq = (int) (*fen) - (int) 'a';
      if(sq > file(KSQ(BLACK))) {
        Pos.castle_flags ^= B_OO_MASK;
        InitialKRSQ = sq;
      }
      else {
        Pos.castle_flags ^= B_OOO_MASK;
        InitialQRSQ = sq;
      }
    }
    fen++;
  }
  while(isspace(*fen)) fen++;
  
  if(*fen=='\0') {
    Pos.rule50 = 0; Pos.ep_square = 0;
  }
  else {
    if(*fen=='-') Pos.ep_square = 0;
    else {
      Pos.ep_square = parse_square(fen);
      if(Pos.ep_square<0) Pos.ep_square=0;
      do{fen++;} while(!isspace(*fen));
    }
    do{fen++;} while(isspace(*fen));
    if(isdigit(*fen)) sscanf(fen, "%d", &Pos.rule50);
    else Pos.rule50=0;
  }

  Pos.key = compute_hash_key();
  Pos.pkey = compute_phash_key();
  init_search();
  GPly=0;
}

void quit(void) {
  free_tt();
  free_pawn_hash_table();
  close_book(Book);
  save_learning();
  exit(0);
}

move_t parse_move(char movestr[]) {
  move_stack_t *ms;
  int from, to, prom;

  if(strlen(movestr)<4) return 0;
  from=parse_square(movestr);
  to=parse_square(movestr+2);
  if(from==-1 || to==-1) return 0;
  if(movestr[4]=='q' || movestr[4]=='Q') prom=QUEEN;
  else if(movestr[4]=='r' || movestr[4]=='R') prom=ROOK;
  else if(movestr[4]=='b' || movestr[4]=='B') prom=BISHOP;
  else if(movestr[4]=='n' || movestr[4]=='N') prom=KNIGHT;
  else prom=0;
  generate_moves();
  for(ms=SearchStack[Ply].ms_ptr; ms<SearchStack[Ply+1].ms_ptr; ms++) {
    if(FROM(ms->move)==from && TO(ms->move)==to && PROMOTION(ms->move)==prom)
      return ms->move;
    else if(SHORT_CASTLING(ms->move) && 
            FROM(ms->move) == from &&
            to == InitialKRSQ + Side * A8)
      return ms->move;
    else if(LONG_CASTLING(ms->move) && 
            FROM(ms->move) == from &&
            to == InitialQRSQ + Side * A8)
      return ms->move;
  }
  return 0;
}

int parse_square(char str[]) {
  if(str[0] >= 'a' && str[0] <= 'h' && str[1] >= '1' && str[1] <= '8')
    return str[0]-'a'+(str[1]-'1')*16;
  else return -1;
}

int get_time(void) {
  struct timeval t;
  gettimeofday(&t, NULL);
  return t.tv_sec*1000 + t.tv_usec/1000; 
}
  
int Bioskey(void);

void check_for_input(void)
{
  int             data;
  char            input[256];
  
  data = Bioskey();
  if (data) {
    if (fgets(input, 255, stdin) == NULL)
      strcpy(input, "quit\n");
    if (strncasecmp(input, "quit", 4) == 0)
      quit();
    else if (strncasecmp(input, "stop", 4) == 0)
      RootSearchInfo.thinking_status = ABORTED;
    else if (strncasecmp(input, "ponderhit", 9) == 0) 
      ponderhit();
  }
}

/*
  From Beowulf, from Olithink
*/
#ifndef _WIN32
/* Non-windows version */
int Bioskey(void)
{
  fd_set          readfds;
  struct timeval  timeout;
  
  FD_ZERO(&readfds);
  FD_SET(fileno(stdin), &readfds);
  /* Set to timeout immediately */
  timeout.tv_sec = 0;
  timeout.tv_usec = 0;
  select(16, &readfds, 0, 0, &timeout);
  
  return (FD_ISSET(fileno(stdin), &readfds));
}

#else
/* Windows-version */
#include <windows.h>
#include <conio.h>
int Bioskey(void)
{
    static int      init = 0,
                    pipe;
    static HANDLE   inh;
    DWORD           dw;
    /* If we're running under XBoard then we can't use _kbhit() as the input
     * commands are sent to us directly over the internal pipe */

#if defined(FILE_CNT)
    if (stdin->_cnt > 0)
        return stdin->_cnt;
#endif
    if (!init) {
        init = 1;
        inh = GetStdHandle(STD_INPUT_HANDLE);
        pipe = !GetConsoleMode(inh, &dw);
        if (!pipe) {
            SetConsoleMode(inh, dw & ~(ENABLE_MOUSE_INPUT | ENABLE_WINDOW_INPUT));
            FlushConsoleInputBuffer(inh);
        }
    }
    if (pipe) {
        if (!PeekNamedPipe(inh, NULL, 0, NULL, &dw, NULL))
            return 1;
        return dw;
    } else {
        GetNumberOfConsoleInputEvents(inh, &dw);
        return dw <= 1 ? 0 : dw;
    }
}
#endif


