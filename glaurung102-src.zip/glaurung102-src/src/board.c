#include "glaurung.h"

void init_board(void) {
  int i;
  for(i=0; i<256; i++) Pos.board_[i] = ((i-64)&0x88)? OUTSIDE : EMPTY;
  Pos.board = Pos.board_ + 64;
}

void init_piece_lists(void) {
  int sq, piece;

  for(piece=KING; piece>=KNIGHT; piece--) {
    PL_START(piece) = piece-1+128; PL_START(piece+8) = piece+7+128;
    PL_PREV(piece-1+128) = piece+128; PL_PREV(piece+7+128) = piece+8+128;
  }
  PL_START(WP) = PL_START(BP) = PL_END;

  for(sq=A1; sq<=H8; sq++) {
    if(Board[sq]==OUTSIDE || Board[sq]==EMPTY) continue;
    PL_INSERT(Board[sq], sq);
  }
}

void copy_position(position_t *pos1, position_t *pos2) {
  memcpy(pos2, pos1, sizeof(position_t));
  pos2->board = pos2->board_ + 64;
}
