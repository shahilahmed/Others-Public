#include "glaurung.h"

int irreversible(move_t m) {
  return CAPTURE(m) || PIECE(m)==PAWN;
}

int ep_is_legal(move_t m) {
  int legal;
  make_move(m);
  legal = !in_check(XSide);
  unmake_move(m);
  return legal;
}

int is_legal(move_t m) {
  int ksq = KSQ(Side);
  int from=FROM(m);
  attack_data_t *a = AttackData-ksq;

  if(SearchStack[Ply].check) return 1;
  if(PIECE(m)==KING) return !is_attacked(TO(m), XSide);
    
  if(a[from].may_attack&Q_MASK) {
    int step = a[from].step, sq;
    if(step==a[TO(m)].step) return 1;
    if(EP(m) && abs(step)==1) return ep_is_legal(m);
    for(sq=from+step; Board[sq]==EMPTY; sq+=step);
    if(sq==ksq) {
      for(sq=from-step; Board[sq]==EMPTY; sq-=step);
      if(COLOUR(Board[sq])==XSide && SLIDER(Board[sq]) &&
         (a[sq].may_attack&PieceMask[Board[sq]]))
        return 0;
    }
  }
  return 1;
}

/* is_check() is a simple function for determining whether a move checks
 * the opponent.  It does not work for promotions, castling or en
 * passant moves. */
int is_check(move_t m) {
  int piece = PIECE(m);
  int from = FROM(m);
  int to = TO(m);
  int ksq = KSQ(XSide);
  int sq, step;
  attack_data_t *a = AttackData-ksq;

  piece |= (Side<<3);
  if(a[to].may_attack & PieceMask[piece]) {
    if(SLIDER(piece)) {
      step=a[to].step;
      for(sq=to+step; Board[sq]==EMPTY; sq+=step);
      if(sq==ksq) return 1;
    }
    else return 1;
  }
  if((a[from].may_attack & Q_MASK) && a[from].step!=a[to].step) {
    step = a[from].step;
    for(sq=from+step; Board[sq]==EMPTY; sq+=step);
    if(sq==ksq) {
      for(sq=from-step; Board[sq]==EMPTY; sq-=step);
      if(COLOUR(Board[sq])==Side && (a[sq].may_attack&PieceMask[Board[sq]]))
        return 1;
    }
  }
  return 0;
}

int pawn_push_to_7th(move_t m) {
  return PIECE(m)==PAWN && PawnRank[Side][TO(m)]==RANK_7;
}

int pawn_push_to_6th(move_t m) {
  return PIECE(m)==PAWN && PawnRank[Side][TO(m)]==RANK_6;
}

void make_move(move_t m) {
  int from, to, piece, capture, promotion, prom_or_piece, ep;
  search_stack_t *ss = SearchStack+Ply;

  ss->move = m;
  ss->undo_info.ep_square = Pos.ep_square;
  ss->undo_info.castle_flags = Pos.castle_flags;
  ss->undo_info.rule50 = Pos.rule50;
  ss->undo_info.key = Pos.previous_keys[GPly] = Pos.key;
  ss->undo_info.pkey = Pos.pkey;
  ss++;
  ss->psq[WHITE] = (ss-1)->psq[WHITE]; ss->psq[BLACK] = (ss-1)->psq[BLACK];
  ss->material[WHITE] = (ss-1)->material[WHITE]; 
  ss->material[BLACK] = (ss-1)->material[BLACK];
  ss->pawns[WHITE] = (ss-1)->pawns[WHITE];
  ss->pawns[BLACK] = (ss-1)->pawns[BLACK];
  ss->evaluated = 0;

  if(irreversible(m)) Pos.rule50 = 0; else Pos.rule50++;

  from=FROM(m); to=TO(m); capture=CAPTURE(m); promotion=PROMOTION(m);
  ep = (m&EP_FLAG);
  piece=Board[from];

  if(capture) capture |= (XSide<<3); 
  if(promotion) promotion |= (Side<<3);
  prom_or_piece = promotion? promotion : piece;
  ss->material[Side] += PieceValues[prom_or_piece]-PieceValues[piece];
  ss->psq[Side] += PSQ(prom_or_piece, to)-PSQ(piece, from);

  Pos.key^=ZOBRIST(piece, from); 
  Pos.key^=ZOBRIST(prom_or_piece, to);
  Pos.key^=ZobColour; Pos.key^=ZOB_EP(Pos.ep_square);

  if(PIECE_TYPE(piece)==PAWN) {
    Pos.pkey^=ZOBRIST(piece, from);
    if(!promotion) Pos.pkey^=ZOBRIST(piece, to);
  }

  if(capture) {
    int capsq = ep? to-PawnPush[Side] : to;
    PL_REMOVE(capsq);
    Board[capsq]=EMPTY;
    Pos.key^=ZOBRIST(capture, capsq);
    if(PIECE_TYPE(capture)==PAWN) Pos.pkey^=ZOBRIST(capture, capsq);
    ss->material[XSide] -= PieceValues[capture];
    ss->psq[XSide] -= PSQ(capture, capsq);
    if(PIECE_TYPE(capture)==PAWN) ss->pawns[XSide]--;
  }
  if(promotion) {
    PL_REMOVE(from); PL_INSERT(promotion, to);
    ss->pawns[Side]--;
  }
  else PL_MOVE(from, to);

  Board[to] = prom_or_piece; Board[from] = EMPTY;

  if(PIECE_TYPE(piece)==PAWN && to-from==2*PawnPush[Side] &&
     (Board[to+1] == ((XSide<<3)|PAWN) || Board[to-1] == ((XSide<<3)|PAWN))) {
    Pos.ep_square = (to+from)/2;
    Pos.key^=ZOB_EP(Pos.ep_square);
  }
  else Pos.ep_square = 0;

  /* FRC castling stuff follows. */
  if(SHORT_CASTLING(m)) {
    int initialKRSQ = InitialKRSQ+Side*A8;
    int rook = FriendlyRook;
    int g1 = G1 + Side*A8, f1 = F1 + Side*A8;

    Board[initialKRSQ] = EMPTY; Board[f1] = rook;
    Board[g1] = FriendlyKing;
    ss->psq[Side] -= PSQ(rook, initialKRSQ); ss->psq[Side] += PSQ(rook, f1);
    Pos.key ^= ZOBRIST(rook, initialKRSQ); Pos.key ^= ZOBRIST(rook, f1);
    init_piece_lists();
  }
  else if(LONG_CASTLING(m)) {
    int initialQRSQ = InitialQRSQ+Side*A8;
    int rook = FriendlyRook;
    int c1 = C1 + Side*A8, d1 = D1 + Side*A8;

    Board[initialQRSQ] = EMPTY; Board[d1] = rook; 
    Board[c1] = FriendlyKing;
    ss->psq[Side] -= PSQ(rook, initialQRSQ); ss->psq[Side] += PSQ(rook, c1);
    Pos.key ^= ZOBRIST(rook, initialQRSQ); Pos.key ^= ZOBRIST(rook, c1);
    init_piece_lists();
  }
  Pos.key^=ZOB_CASTLE(Pos.castle_flags);
  if(from==InitialKSQ || from==InitialKRSQ || to==InitialKRSQ)
    PROHIBIT_WHITE_OO();
  if(from==InitialKSQ || from==InitialQRSQ || to==InitialQRSQ)
    PROHIBIT_WHITE_OOO();
  if(from==InitialKSQ+A8 || from==InitialKRSQ+A8 || to==InitialKRSQ+A8)
    PROHIBIT_BLACK_OO();
  if(from==InitialKSQ+A8 || from==InitialQRSQ+A8 || to==InitialQRSQ+A8)
    PROHIBIT_BLACK_OOO();
  Pos.key^=ZOB_CASTLE(Pos.castle_flags);

  Ply++; GPly++; Side^=1; XSide^=1;
  ss->inceval = 
    ss->material[Side]-ss->material[XSide]+ss->psq[Side]-ss->psq[XSide];
}

void unmake_move(move_t m) {
  int from, to, piece, capture, promotion, prom_or_piece, ep;

  Ply--; GPly--; XSide^=1; Side^=1;
  Pos.ep_square = SearchStack[Ply].undo_info.ep_square;
  Pos.castle_flags = SearchStack[Ply].undo_info.castle_flags;
  Pos.rule50 = SearchStack[Ply].undo_info.rule50;
  Pos.key = SearchStack[Ply].undo_info.key;
  Pos.pkey = SearchStack[Ply].undo_info.pkey;

  from=FROM(m); to=TO(m); capture=CAPTURE(m); promotion=PROMOTION(m);
  piece=PIECE(m); ep = (m&EP_FLAG);

  piece |= (Side<<3);
  if(capture) capture |= (XSide<<3); 
  if(promotion) promotion |= (Side<<3);
  prom_or_piece = promotion? promotion : piece;

  if(promotion) {
    PL_REMOVE(to); PL_INSERT(piece, from);
  }
  else PL_MOVE(to, from);
  Board[from] = piece; Board[to] = EMPTY;

  if(capture) {
    int capsq = ep? to-PawnPush[Side] : to;
    Board[capsq] = capture;
    PL_INSERT(capture, capsq);
  }

  /* FRC castling stuff follows. */
  if(SHORT_CASTLING(m)) {
    int initialKRSQ = InitialKRSQ+Side*A8, initialKSQ = InitialKSQ+Side*A8;
    int rook = FriendlyRook, king = FriendlyKing;
    int g1 = G1 + Side*A8, f1 = F1 + Side*A8;

    Board[f1] = Board[g1] = EMPTY;
    Board[initialKRSQ] = rook; Board[initialKSQ] = king;
    init_piece_lists();
  }
  if(LONG_CASTLING(m)) {
    int initialQRSQ = InitialQRSQ+Side*A8, initialKSQ = InitialKSQ+Side*A8;
    int rook = FriendlyRook, king = FriendlyKing;
    int c1 = C1 + Side*A8, d1 = D1 + Side*A8;

    Board[d1] = Board[c1] = EMPTY;
    Board[initialQRSQ] = rook; Board[initialKSQ] = king;
    init_piece_lists();
  }
}

void make_nullmove(void) {
  search_stack_t *ss = SearchStack+Ply;
  ss->move = 0;
  ss->undo_info.ep_square = Pos.ep_square;
  ss->undo_info.castle_flags = Pos.castle_flags;
  ss->undo_info.rule50 = Pos.rule50;
  ss->undo_info.key = Pos.previous_keys[GPly] = Pos.key;
  ss++;
  ss->psq[WHITE] = (ss-1)->psq[WHITE]; ss->psq[BLACK] = (ss-1)->psq[BLACK];
  ss->material[WHITE] = (ss-1)->material[WHITE]; 
  ss->material[BLACK] = (ss-1)->material[BLACK];
  ss->pawns[WHITE] = (ss-1)->pawns[WHITE];
  ss->pawns[BLACK] = (ss-1)->pawns[BLACK];
  ss->ms_ptr = (ss-1)->ms_ptr;
  ss->evaluated = 0;
  Pos.key^=ZobColour; Pos.key^=ZOB_EP(Pos.ep_square);
  Pos.rule50++; 
  Pos.ep_square = 0;
  Ply++; GPly++; Side^=1; XSide^=1;
  ss->inceval = 
    ss->material[Side]-ss->material[XSide]+ss->psq[Side]-ss->psq[XSide];
}

void unmake_nullmove(void) {
  Ply--; GPly--; XSide^=1; Side^=1;
  Pos.ep_square = SearchStack[Ply].undo_info.ep_square;
  Pos.castle_flags = SearchStack[Ply].undo_info.castle_flags;
  Pos.rule50 = SearchStack[Ply].undo_info.rule50;
  Pos.key = SearchStack[Ply].undo_info.key;
}
    
